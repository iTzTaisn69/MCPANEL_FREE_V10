import { createServer } from 'http'
import { Server } from 'socket.io'

const httpServer = createServer()
const io = new Server(httpServer, {
  path: '/',
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  },
  pingTimeout: 60000,
  pingInterval: 25000,
})

// Store server states in memory
const serverStates = new Map<number, {
  status: string
  cpu: number
  ram: number
  disk: number
  players: string[]
  consoleOutput: string[]
}>()

// Minecraft-style log messages for simulation
const mcLogMessages = [
  '[{time}] [Server thread/INFO]: Starting minecraft server version 1.21.4',
  '[{time}] [Server thread/INFO]: Loading properties',
  '[{time}] [Server thread/INFO]: Default game type: SURVIVAL',
  '[{time}] [Server thread/INFO]: Generating keypair',
  '[{time}] [Server thread/INFO]: Starting Minecraft server on *:25565',
  '[{time}] [Server thread/INFO]: Preparing level "world"',
  '[{time}] [Server thread/INFO]: Preparing start region for dimension minecraft:overworld',
  '[{time}] [Server thread/INFO]: Time elapsed: {ms} ms',
  '[{time}] [Server thread/INFO]: Done ({ms}s)! For help, type "help"',
  '[{time}] [Server thread/INFO]: Steve joined the game',
  '[{time}] [Server thread/INFO]: Alex joined the game',
  '[{time}] [Server thread/INFO]: Notch joined the game',
  '[{time}] [Server thread/INFO]: Herobrine left the game',
  '[{time}] [Server thread/INFO]: <Steve> Hello world!',
  '[{time}] [Server thread/INFO]: <Alex> Anyone want to build?',
  '[{time}] [Server thread/INFO]: <Notch> Nice server!',
  '[{time}] [Server thread/WARN]: Can\'t keep up! Is the server overloaded? Running {ms}ms behind',
  '[{time}] [Server thread/INFO]: Saving worlds',
  '[{time}] [Server thread/INFO]: Saved the world',
  '[{time}] [Server thread/INFO]: Stopping the server',
  '[{time}] [Server thread/INFO]: Saving chunks for level \'world\'/minecraft:overworld',
  '[{time}] [Server thread/INFO]: ThreadedAnvilChunkStorage: All dimensions are saved',
  '[{time}] [Server thread/INFO]: Steve earned the achievement [Diamonds!]',
  '[{time}] [Server thread/INFO]: Alex was slain by Zombie',
  '[{time}] [Server thread/INFO]: Notch made a Stone Pickaxe',
  '[{time}] [Server thread/INFO]: Preparing spawn area: {progress}%',
]

const playerNames = ['Steve', 'Alex', 'Notch', 'Herobrine', 'Dream', 'Technoblade', 'Philza', 'TommyInnit', 'Tubbo', 'Ranboo']

function getTimeStr(): string {
  const now = new Date()
  return `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`
}

function generateLogLine(): string {
  const template = mcLogMessages[Math.floor(Math.random() * mcLogMessages.length)]
  return template
    .replace('{time}', getTimeStr())
    .replace('{ms}', String(Math.floor(Math.random() * 3000) + 100))
    .replace('{progress}', String(Math.floor(Math.random() * 100)))
}

function initServerState(serverId: number) {
  if (!serverStates.has(serverId)) {
    serverStates.set(serverId, {
      status: 'online',
      cpu: Math.floor(Math.random() * 40) + 10,
      ram: Math.floor(Math.random() * 30) + 30,
      disk: Math.floor(Math.random() * 20) + 40,
      players: playerNames.slice(0, Math.floor(Math.random() * 5) + 1),
      consoleOutput: []
    })
  }
}

// Simulate server stats updates
const statsInterval = setInterval(() => {
  serverStates.forEach((state, serverId) => {
    if (state.status === 'online') {
      // Fluctuate CPU/RAM
      state.cpu = Math.max(5, Math.min(95, state.cpu + (Math.random() - 0.5) * 10))
      state.ram = Math.max(20, Math.min(90, state.ram + (Math.random() - 0.5) * 5))
      state.disk = Math.max(30, Math.min(85, state.disk + (Math.random() - 0.5) * 2))

      // Random player join/leave
      if (Math.random() > 0.9) {
        const action = Math.random() > 0.5 ? 'joined' : 'left'
        const player = playerNames[Math.floor(Math.random() * playerNames.length)]
        if (action === 'joined' && !state.players.includes(player)) {
          state.players.push(player)
          const logLine = `[${getTimeStr()}] [Server thread/INFO]: ${player} ${action} the game`
          state.consoleOutput.push(logLine)
          io.to(`server-${serverId}`).emit('console-output', { serverId, line: logLine })
        } else if (action === 'left' && state.players.includes(player)) {
          state.players = state.players.filter(p => p !== player)
          const logLine = `[${getTimeStr()}] [Server thread/INFO]: ${player} ${action} the game`
          state.consoleOutput.push(logLine)
          io.to(`server-${serverId}`).emit('console-output', { serverId, line: logLine })
        }
      }

      io.to(`server-${serverId}`).emit('server-stats', {
        serverId,
        cpu: Math.round(state.cpu),
        ram: Math.round(state.ram),
        disk: Math.round(state.disk),
        playerCount: state.players.length,
        players: state.players
      })
    }
  })
}, 3000)

// Simulate console output for online servers
const consoleInterval = setInterval(() => {
  serverStates.forEach((state, serverId) => {
    if (state.status === 'online' && Math.random() > 0.4) {
      const logLine = generateLogLine()
      state.consoleOutput.push(logLine)
      // Keep only last 500 lines
      if (state.consoleOutput.length > 500) {
        state.consoleOutput = state.consoleOutput.slice(-500)
      }
      io.to(`server-${serverId}`).emit('console-output', { serverId, line: logLine })
    }
  })
}, 4000)

io.on('connection', (socket) => {
  console.log(`Client connected: ${socket.id}`)

  socket.on('join-server', (data: { serverId: number }) => {
    const { serverId } = data
    socket.join(`server-${serverId}`)
    initServerState(serverId)
    
    const state = serverStates.get(serverId)!
    // Send current state to newly joined client
    socket.emit('server-stats', {
      serverId,
      cpu: Math.round(state.cpu),
      ram: Math.round(state.ram),
      disk: Math.round(state.disk),
      playerCount: state.players.length,
      players: state.players
    })
    
    // Send last 50 console lines
    state.consoleOutput.slice(-50).forEach(line => {
      socket.emit('console-output', { serverId, line })
    })
    
    console.log(`Client ${socket.id} joined server room: server-${serverId}`)
  })

  socket.on('leave-server', (data: { serverId: number }) => {
    socket.leave(`server-${serverId}`)
    console.log(`Client ${socket.id} left server room: server-${serverId}`)
  })

  socket.on('server-command', (data: { serverId: number; command: string }) => {
    const { serverId, command } = data
    const state = serverStates.get(serverId)
    
    // Echo command to console
    const cmdLine = `[${getTimeStr()}] [Server thread/INFO]: > ${command}`
    if (state) {
      state.consoleOutput.push(cmdLine)
    }
    io.to(`server-${serverId}`).emit('console-output', { serverId, line: cmdLine })
    
    // Simulate command response
    setTimeout(() => {
      let response = ''
      if (command === 'help') {
        response = `[${getTimeStr()}] [Server thread/INFO]: Available commands: help, list, say, op, deop, stop, gamemode, time, weather, tp, give`
      } else if (command === 'list') {
        response = state 
          ? `[${getTimeStr()}] [Server thread/INFO]: There are ${state.players.length} of a max of 20 players online: ${state.players.join(', ')}`
          : `[${getTimeStr()}] [Server thread/INFO]: No players online`
      } else if (command.startsWith('say ')) {
        response = `[${getTimeStr()}] [Server thread/INFO]: [Server] ${command.slice(4)}`
      } else if (command === 'stop') {
        response = `[${getTimeStr()}] [Server thread/INFO]: Stopping the server`
        if (state) state.status = 'stopping'
        io.to(`server-${serverId}`).emit('server-status-change', { serverId, status: 'stopping' })
        setTimeout(() => {
          if (state) state.status = 'stopped'
          io.to(`server-${serverId}`).emit('server-status-change', { serverId, status: 'stopped' })
        }, 3000)
      } else if (command.startsWith('gamemode ')) {
        response = `[${getTimeStr()}] [Server thread/INFO]: Set game mode to ${command.slice(9)}`
      } else if (command.startsWith('time set ')) {
        response = `[${getTimeStr()}] [Server thread/INFO]: Set the time to ${command.slice(9)}`
      } else {
        response = `[${getTimeStr()}] [Server thread/INFO]: Unknown command "${command}". Type "help" for available commands.`
      }
      
      if (state) state.consoleOutput.push(response)
      io.to(`server-${serverId}`).emit('console-output', { serverId, line: response })
    }, 500)
  })

  socket.on('start-server', (data: { serverId: number }) => {
    const { serverId } = data
    initServerState(serverId)
    const state = serverStates.get(serverId)!
    
    io.to(`server-${serverId}`).emit('server-status-change', { serverId, status: 'starting' })
    
    // Simulate startup sequence
    const startupMessages = [
      `[${getTimeStr()}] [Server thread/INFO]: Starting minecraft server version 1.21.4`,
      `[${getTimeStr()}] [Server thread/INFO]: Loading properties`,
      `[${getTimeStr()}] [Server thread/INFO]: Default game type: SURVIVAL`,
      `[${getTimeStr()}] [Server thread/INFO]: Generating keypair`,
      `[${getTimeStr()}] [Server thread/INFO]: Starting Minecraft server on *:25565`,
      `[${getTimeStr()}] [Server thread/INFO]: Preparing level "world"`,
      `[${getTimeStr()}] [Server thread/INFO]: Preparing start region for dimension minecraft:overworld`,
    ]
    
    startupMessages.forEach((msg, i) => {
      setTimeout(() => {
        state.consoleOutput.push(msg)
        io.to(`server-${serverId}`).emit('console-output', { serverId, line: msg })
      }, (i + 1) * 800)
    })
    
    setTimeout(() => {
      const doneMsg = `[${getTimeStr()}] [Server thread/INFO]: Done (2.347s)! For help, type "help"`
      state.consoleOutput.push(doneMsg)
      state.status = 'online'
      io.to(`server-${serverId}`).emit('console-output', { serverId, line: doneMsg })
      io.to(`server-${serverId}`).emit('server-status-change', { serverId, status: 'online' })
    }, startupMessages.length * 800 + 500)
  })

  socket.on('stop-server', (data: { serverId: number }) => {
    const { serverId } = data
    const state = serverStates.get(serverId)
    if (state) state.status = 'stopping'
    
    io.to(`server-${serverId}`).emit('server-status-change', { serverId, status: 'stopping' })
    
    const stopMsg = `[${getTimeStr()}] [Server thread/INFO]: Stopping the server`
    const saveMsg = `[${getTimeStr()}] [Server thread/INFO]: Saving worlds`
    const savedMsg = `[${getTimeStr()}] [Server thread/INFO]: Saved the world`
    
    if (state) state.consoleOutput.push(stopMsg)
    io.to(`server-${serverId}`).emit('console-output', { serverId, line: stopMsg })
    
    setTimeout(() => {
      if (state) state.consoleOutput.push(saveMsg)
      io.to(`server-${serverId}`).emit('console-output', { serverId, line: saveMsg })
    }, 1000)
    
    setTimeout(() => {
      if (state) state.consoleOutput.push(savedMsg)
      io.to(`server-${serverId}`).emit('console-output', { serverId, line: savedMsg })
    }, 2000)
    
    setTimeout(() => {
      if (state) state.status = 'stopped'
      io.to(`server-${serverId}`).emit('server-status-change', { serverId, status: 'stopped' })
    }, 3000)
  })

  socket.on('restart-server', (data: { serverId: number }) => {
    const { serverId } = data
    const state = serverStates.get(serverId)
    if (state) state.status = 'restarting'
    
    io.to(`server-${serverId}`).emit('server-status-change', { serverId, status: 'restarting' })
    
    const restartMsg = `[${getTimeStr()}] [Server thread/INFO]: Restarting server...`
    if (state) state.consoleOutput.push(restartMsg)
    io.to(`server-${serverId}`).emit('console-output', { serverId, line: restartMsg })
    
    setTimeout(() => {
      if (state) state.status = 'stopped'
      io.to(`server-${serverId}`).emit('server-status-change', { serverId, status: 'stopped' })
      
      // Auto-restart after brief stop
      setTimeout(() => {
        socket.emit('start-server', { serverId })
        io.to(`server-${serverId}`).emit('server-status-change', { serverId, status: 'starting' })
        initServerState(serverId)
        const newState = serverStates.get(serverId)!
        newState.status = 'starting'
        
        setTimeout(() => {
          newState.status = 'online'
          const doneMsg = `[${getTimeStr()}] [Server thread/INFO]: Done (1.892s)! For help, type "help"`
          newState.consoleOutput.push(doneMsg)
          io.to(`server-${serverId}`).emit('console-output', { serverId, line: doneMsg })
          io.to(`server-${serverId}`).emit('server-status-change', { serverId, status: 'online' })
        }, 5000)
      }, 2000)
    }, 3000)
  })

  socket.on('disconnect', () => {
    console.log(`Client disconnected: ${socket.id}`)
  })
})

const PORT = 3003
httpServer.listen(PORT, () => {
  console.log(`MCPanel Socket.IO service running on port ${PORT}`)
})

process.on('SIGTERM', () => {
  clearInterval(statsInterval)
  clearInterval(consoleInterval)
  httpServer.close(() => process.exit(0))
})

process.on('SIGINT', () => {
  clearInterval(statsInterval)
  clearInterval(consoleInterval)
  httpServer.close(() => process.exit(0))
})
