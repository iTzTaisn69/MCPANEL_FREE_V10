import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserFromRequest } from '@/lib/auth'

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getUserFromRequest(request)
    if (!user) {
      return NextResponse.json({ success: false, error: 'Not authenticated' }, { status: 401 })
    }

    const { id } = await params
    const serverId = parseInt(id)

    const server = await db.server.findUnique({
      where: { id: serverId },
      include: {
        owner: { select: { username: true, displayName: true } },
        members: { include: { user: { select: { username: true, displayName: true } } } },
        backups: { orderBy: { createdAt: 'desc' } },
      },
    })

    if (!server) {
      return NextResponse.json({ success: false, error: 'Server not found' }, { status: 404 })
    }

    // Check access
    const hasAccess = user.role === 'admin' ||
      server.ownerId === user.id ||
      server.members.some(m => m.userId === user.id)

    if (!hasAccess) {
      return NextResponse.json({ success: false, error: 'Access denied' }, { status: 403 })
    }

    return NextResponse.json({ success: true, server })
  } catch (error) {
    console.error('Get server error:', error)
    return NextResponse.json({ success: false, error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getUserFromRequest(request)
    if (!user) {
      return NextResponse.json({ success: false, error: 'Not authenticated' }, { status: 401 })
    }

    if (user.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 })
    }

    const { id } = await params
    const serverId = parseInt(id)

    await db.backup.deleteMany({ where: { serverId } })
    await db.serverMember.deleteMany({ where: { serverId } })
    await db.server.delete({ where: { id: serverId } })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Delete server error:', error)
    return NextResponse.json({ success: false, error: 'Internal server error' }, { status: 500 })
  }
}
