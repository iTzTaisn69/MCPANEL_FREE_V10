import { NextResponse } from 'next/server'
import { getUserFromRequest } from '@/lib/auth'

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getUserFromRequest(request)
    if (!user) {
      return NextResponse.json({ success: false, error: 'Not authenticated' }, { status: 401 })
    }

    const { id } = await params
    // Return mock stats
    const stats = {
      serverId: parseInt(id),
      cpu: Math.floor(Math.random() * 40) + 15,
      ram: Math.floor(Math.random() * 30) + 35,
      disk: Math.floor(Math.random() * 20) + 40,
      playerCount: Math.floor(Math.random() * 10),
      players: ['Steve', 'Alex', 'Notch'].slice(0, Math.floor(Math.random() * 3) + 1),
      uptime: Math.floor(Math.random() * 86400),
      tps: 19.5 + Math.random() * 0.5,
    }

    return NextResponse.json({ success: true, stats })
  } catch (error) {
    console.error('Stats error:', error)
    return NextResponse.json({ success: false, error: 'Internal server error' }, { status: 500 })
  }
}
