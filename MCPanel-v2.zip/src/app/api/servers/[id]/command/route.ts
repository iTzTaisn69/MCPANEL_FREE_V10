import { NextResponse } from 'next/server'
import { getUserFromRequest } from '@/lib/auth'

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getUserFromRequest(request)
    if (!user) {
      return NextResponse.json({ success: false, error: 'Not authenticated' }, { status: 401 })
    }

    const { id } = await params
    const { command } = await request.json()

    if (!command) {
      return NextResponse.json({ success: false, error: 'Command is required' }, { status: 400 })
    }

    return NextResponse.json({ success: true, message: `Command sent to server ${id}` })
  } catch (error) {
    console.error('Command error:', error)
    return NextResponse.json({ success: false, error: 'Internal server error' }, { status: 500 })
  }
}
