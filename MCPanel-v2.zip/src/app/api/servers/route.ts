import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserFromRequest } from '@/lib/auth'

export async function GET(request: Request) {
  try {
    const user = await getUserFromRequest(request)
    if (!user) {
      return NextResponse.json({ success: false, error: 'Not authenticated' }, { status: 401 })
    }

    let servers
    if (user.role === 'admin') {
      servers = await db.server.findMany({
        include: {
          owner: { select: { username: true, displayName: true } },
          members: { include: { user: { select: { username: true, displayName: true } } } },
        },
        orderBy: { createdAt: 'desc' },
      })
    } else {
      servers = await db.server.findMany({
        where: {
          OR: [
            { ownerId: user.id },
            { members: { some: { userId: user.id } } },
          ],
        },
        include: {
          owner: { select: { username: true, displayName: true } },
          members: { include: { user: { select: { username: true, displayName: true } } } },
        },
        orderBy: { createdAt: 'desc' },
      })
    }

    return NextResponse.json({ success: true, servers })
  } catch (error) {
    console.error('List servers error:', error)
    return NextResponse.json({ success: false, error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const user = await getUserFromRequest(request)
    if (!user) {
      return NextResponse.json({ success: false, error: 'Not authenticated' }, { status: 401 })
    }

    if (user.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 })
    }

    const body = await request.json()
    const { name, ram, cpu, disk, port, serverType, version } = body

    if (!name) {
      return NextResponse.json({ success: false, error: 'Server name is required' }, { status: 400 })
    }

    const server = await db.server.create({
      data: {
        name,
        ownerId: user.id,
        ram: ram || 1024,
        cpu: cpu || 1,
        disk: disk || 10240,
        port: port || 25565,
        serverType: serverType || 'vanilla',
        version: version || '1.21.4',
        status: 'stopped',
      },
      include: {
        owner: { select: { username: true, displayName: true } },
      },
    })

    // Add owner as admin member
    await db.serverMember.create({
      data: {
        serverId: server.id,
        userId: user.id,
        role: 'admin',
        permissions: JSON.stringify(['*']),
      },
    })

    return NextResponse.json({ success: true, server })
  } catch (error) {
    console.error('Create server error:', error)
    return NextResponse.json({ success: false, error: 'Internal server error' }, { status: 500 })
  }
}
