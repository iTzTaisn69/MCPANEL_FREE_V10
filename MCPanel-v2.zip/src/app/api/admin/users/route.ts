import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserFromRequest, hashPassword } from '@/lib/auth'

export async function GET(request: Request) {
  try {
    const user = await getUserFromRequest(request)
    if (!user) {
      return NextResponse.json({ success: false, error: 'Not authenticated' }, { status: 401 })
    }

    if (user.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 })
    }

    const users = await db.user.findMany({
      select: {
        id: true,
        username: true,
        email: true,
        role: true,
        status: true,
        displayName: true,
        avatar: true,
        createdAt: true,
        _count: { select: { ownedServers: true, memberships: true } },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ success: true, users })
  } catch (error) {
    console.error('List users error:', error)
    return NextResponse.json({ success: false, error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const user = await getUserFromRequest(request)
    if (!user) {
      return NextResponse.json({ success: false, error: 'Not authenticated' }, { status: 401 })
    }

    if (user.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 })
    }

    const { username, email, password, role, displayName } = await request.json()

    if (!username || !email || !password) {
      return NextResponse.json({ success: false, error: 'Required fields missing' }, { status: 400 })
    }

    const existing = await db.user.findFirst({
      where: { OR: [{ username }, { email }] },
    })

    if (existing) {
      return NextResponse.json({ success: false, error: 'Username or email already exists' }, { status: 409 })
    }

    const hashedPassword = await hashPassword(password)

    const newUser = await db.user.create({
      data: {
        username,
        email,
        password: hashedPassword,
        role: role || 'user',
        displayName: displayName || username,
      },
    })

    return NextResponse.json({ success: true, user: newUser })
  } catch (error) {
    console.error('Create user error:', error)
    return NextResponse.json({ success: false, error: 'Internal server error' }, { status: 500 })
  }
}
