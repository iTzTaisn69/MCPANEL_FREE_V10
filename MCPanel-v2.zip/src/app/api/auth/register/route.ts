import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { hashPassword, generateToken } from '@/lib/auth'

export async function POST(request: Request) {
  try {
    const { username, email, password } = await request.json()

    if (!username || !email || !password) {
      return NextResponse.json({ success: false, error: 'All fields are required' }, { status: 400 })
    }

    if (password.length < 6) {
      return NextResponse.json({ success: false, error: 'Password must be at least 6 characters' }, { status: 400 })
    }

    const existingUser = await db.user.findFirst({
      where: { OR: [{ username }, { email }] },
    })

    if (existingUser) {
      return NextResponse.json({ success: false, error: 'Username or email already exists' }, { status: 409 })
    }

    const hashedPassword = await hashPassword(password)

    // Check if this is the first user (make admin)
    const userCount = await db.user.count()

    const user = await db.user.create({
      data: {
        username,
        email,
        password: hashedPassword,
        role: userCount === 0 ? 'admin' : 'user',
        displayName: username,
      },
    })

    const authUser = {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      status: user.status,
      displayName: user.displayName,
      avatar: user.avatar,
    }

    const token = generateToken(authUser)

    return NextResponse.json({
      success: true,
      token,
      user: authUser,
    })
  } catch (error) {
    console.error('Register error:', error)
    return NextResponse.json({ success: false, error: 'Internal server error' }, { status: 500 })
  }
}
