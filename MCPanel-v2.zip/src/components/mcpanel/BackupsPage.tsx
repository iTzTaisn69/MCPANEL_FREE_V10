'use client'

import { useEffect, useState } from 'react'
import { useServerStore } from '@/stores/serverStore'
import { useUIStore } from '@/stores/uiStore'
import { cn } from '@/lib/utils'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  HardDrive,
  Download,
  RotateCcw,
  Plus,
  Clock,
  Database,
  AlertTriangle,
} from 'lucide-react'

export function BackupsPage() {
  const { servers, selectedServerId, selectServer } = useServerStore()
  const { navigateToServer } = useUIStore()
  const server = servers.find(s => s.id === selectedServerId)
  const [backups, setBackups] = useState<Array<{ id: number; name: string; size: string | null; createdAt: string }>>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (selectedServerId) {
      selectServer(selectedServerId).then(() => {
        // After selecting server, it should have backups
        const s = useServerStore.getState().selectedServer
        if (s?.backups) {
          setBackups(s.backups)
        }
        setLoading(false)
      })
    }
  }, [selectedServerId, selectServer])

  if (!server) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <HardDrive className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground">No server selected</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4 fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-white">Server Backups</h2>
          <p className="text-sm text-muted-foreground mt-0.5">
            Create and restore backups for {server.name}
          </p>
        </div>
        <Button className="bg-gradient-to-r from-emerald-500 to-cyan-500 text-black font-semibold shadow-lg shadow-emerald-500/20">
          <Plus className="w-4 h-4 mr-1.5" /> Create Backup
        </Button>
      </div>

      {/* Warning */}
      <div className="flex items-start gap-3 p-4 rounded-lg bg-amber-500/5 border border-amber-500/10">
        <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
        <div>
          <p className="text-sm text-amber-200 font-medium">Backup Notice</p>
          <p className="text-xs text-amber-200/60 mt-0.5">
            Restoring a backup will replace the current world data. This action cannot be undone. 
            Make sure to create a new backup before restoring.
          </p>
        </div>
      </div>

      {/* Backups list */}
      <Card className="bg-[#111318] border-white/[0.06]">
        <CardContent className="p-0">
          <div className="divide-y divide-white/[0.03]">
            {(backups.length > 0 ? backups : [
              { id: 1, name: 'Daily Backup', size: '234.5 MB', createdAt: new Date().toISOString() },
              { id: 2, name: 'Pre-update Backup', size: '189.2 MB', createdAt: new Date(Date.now() - 86400000).toISOString() },
              { id: 3, name: 'World Save', size: '312.8 MB', createdAt: new Date(Date.now() - 86400000 * 2).toISOString() },
            ]).map((backup) => (
              <div key={backup.id} className="flex items-center gap-4 px-5 py-4 hover:bg-white/[0.02] transition-colors group">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center flex-shrink-0">
                  <Database className="w-5 h-5 text-cyan-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-white font-medium">{backup.name}</p>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="text-xs text-muted-foreground">
                      <Clock className="w-3 h-3 inline mr-1" />
                      {new Date(backup.createdAt).toLocaleString()}
                    </span>
                    {backup.size && (
                      <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 border-0 bg-white/5 text-muted-foreground">
                        {backup.size}
                      </Badge>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button variant="ghost" size="sm" className="h-7 text-xs text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10 px-2.5">
                    <RotateCcw className="w-3 h-3 mr-1" /> Restore
                  </Button>
                  <Button variant="ghost" size="sm" className="h-7 text-xs text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10 px-2.5">
                    <Download className="w-3 h-3 mr-1" /> Download
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
