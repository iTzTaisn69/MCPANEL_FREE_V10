'use client'

import { useEffect } from 'react'
import { useAuthStore } from '@/stores/authStore'
import { useServerStore } from '@/stores/serverStore'
import { useUIStore } from '@/stores/uiStore'
import { cn } from '@/lib/utils'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import {
  Server as ServerIcon,
  Activity,
  Users,
  HardDrive,
  Play,
  Square,
  RotateCcw,
  ChevronRight,
  Cpu,
  MemoryStick,
  Wifi,
  WifiOff,
} from 'lucide-react'

export function DashboardPage() {
  const { user } = useAuthStore()
  const { servers, fetchServers, startServer, stopServer } = useServerStore()
  const { navigateToServer } = useUIStore()

  useEffect(() => {
    fetchServers()
  }, [fetchServers])

  const onlineServers = servers.filter(s => s.status === 'online')
  const offlineServers = servers.filter(s => s.status === 'stopped')
  const totalPlayers = Math.floor(Math.random() * 20) + 5

  const stats = [
    {
      title: 'Total Servers',
      value: servers.length,
      icon: ServerIcon,
      color: 'from-emerald-500/20 to-emerald-500/5',
      iconColor: 'text-emerald-400',
      change: '+2 this week',
    },
    {
      title: 'Online',
      value: onlineServers.length,
      icon: Wifi,
      color: 'from-green-500/20 to-green-500/5',
      iconColor: 'text-green-400',
      change: 'Active now',
    },
    {
      title: 'Offline',
      value: offlineServers.length,
      icon: WifiOff,
      color: 'from-red-500/20 to-red-500/5',
      iconColor: 'text-red-400',
      change: 'Needs attention',
    },
    {
      title: 'Players Online',
      value: totalPlayers,
      icon: Users,
      color: 'from-cyan-500/20 to-cyan-500/5',
      iconColor: 'text-cyan-400',
      change: 'Across all servers',
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-emerald-400'
      case 'starting': case 'stopping': case 'restarting': return 'bg-amber-400'
      default: return 'bg-white/20'
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'online': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
      case 'starting': case 'stopping': case 'restarting': return 'bg-amber-500/10 text-amber-400 border-amber-500/20'
      default: return 'bg-white/5 text-muted-foreground border-white/10'
    }
  }

  const getTypeBadge = (type: string) => {
    switch (type) {
      case 'vanilla': return 'bg-emerald-500/10 text-emerald-400'
      case 'spigot': return 'bg-amber-500/10 text-amber-400'
      case 'paper': return 'bg-blue-500/10 text-blue-400'
      case 'purpur': return 'bg-purple-500/10 text-purple-400'
      case 'forge': return 'bg-red-500/10 text-red-400'
      default: return 'bg-white/5 text-muted-foreground'
    }
  }

  return (
    <div className="space-y-6 fade-in">
      {/* Welcome header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">
            Welcome back, {user?.displayName || user?.username} 👋
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Here&apos;s an overview of your Minecraft servers.
          </p>
        </div>
        {user?.role === 'admin' && (
          <Button
            onClick={() => fetchServers()}
            variant="outline"
            size="sm"
            className="border-white/10 text-muted-foreground hover:text-white hover:bg-white/[0.04]"
          >
            <Activity className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        )}
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <Card key={stat.title} className="bg-[#111318] border-white/[0.06] overflow-hidden relative">
            <CardContent className="p-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">{stat.title}</p>
                  <p className="text-3xl font-bold text-white mt-2">{stat.value}</p>
                  <p className="text-xs text-muted-foreground/60 mt-1">{stat.change}</p>
                </div>
                <div className={cn("w-10 h-10 rounded-xl bg-gradient-to-br flex items-center justify-center", stat.color)}>
                  <stat.icon className={cn("w-5 h-5", stat.iconColor)} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Servers section */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-white">Your Servers</h2>
          <Badge variant="outline" className="text-xs border-white/10 text-muted-foreground">
            {servers.length} total
          </Badge>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {servers.map((server) => (
            <Card
              key={server.id}
              className="bg-[#111318] border-white/[0.06] hover:border-emerald-500/20 transition-all duration-300 cursor-pointer group"
              onClick={() => navigateToServer(server.id)}
            >
              <CardContent className="p-5">
                {/* Server header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",
                      server.status === 'online'
                        ? 'bg-emerald-500/10'
                        : 'bg-white/5'
                    )}>
                      <ServerIcon className={cn(
                        "w-5 h-5",
                        server.status === 'online' ? 'text-emerald-400' : 'text-muted-foreground'
                      )} />
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-semibold text-white truncate group-hover:text-emerald-400 transition-colors">
                        {server.name}
                      </h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline" className={`text-[10px] px-1.5 py-0 h-4 border-0 ${getTypeBadge(server.serverType)}`}>
                          {server.serverType}
                        </Badge>
                        <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 border-0 bg-white/5 text-muted-foreground">
                          v{server.version}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className={cn("w-2 h-2 rounded-full", getStatusColor(server.status), server.status === 'online' && 'pulse-dot')} />
                    <span className={cn("text-[10px] capitalize", 
                      server.status === 'online' ? 'text-emerald-400' :
                      server.status === 'starting' || server.status === 'stopping' || server.status === 'restarting'
                      ? 'text-amber-400' : 'text-muted-foreground'
                    )}>
                      {server.status}
                    </span>
                  </div>
                </div>

                {/* Resource bars */}
                <div className="space-y-2.5 mb-4">
                  <div className="flex items-center gap-2">
                    <Cpu className="w-3 h-3 text-muted-foreground flex-shrink-0" />
                    <div className="flex-1">
                      <Progress value={server.status === 'online' ? 45 : 0} className="h-1.5 bg-white/5" />
                    </div>
                    <span className="text-[10px] text-muted-foreground w-8 text-right">
                      {server.status === 'online' ? '45%' : '0%'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MemoryStick className="w-3 h-3 text-muted-foreground flex-shrink-0" />
                    <div className="flex-1">
                      <Progress value={server.status === 'online' ? 62 : 0} className="h-1.5 bg-white/5" />
                    </div>
                    <span className="text-[10px] text-muted-foreground w-8 text-right">
                      {server.status === 'online' ? '62%' : '0%'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <HardDrive className="w-3 h-3 text-muted-foreground flex-shrink-0" />
                    <div className="flex-1">
                      <Progress value={server.status === 'online' ? 35 : 0} className="h-1.5 bg-white/5" />
                    </div>
                    <span className="text-[10px] text-muted-foreground w-8 text-right">
                      {server.status === 'online' ? '35%' : '0%'}
                    </span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 pt-3 border-t border-white/[0.04]">
                  {server.status === 'online' ? (
                    <>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-7 text-xs text-destructive hover:text-destructive hover:bg-destructive/10 px-2"
                        onClick={(e) => { e.stopPropagation(); stopServer(server.id) }}
                      >
                        <Square className="w-3 h-3 mr-1" /> Stop
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-7 text-xs text-amber-400 hover:text-amber-300 hover:bg-amber-500/10 px-2"
                        onClick={(e) => { e.stopPropagation() }}
                      >
                        <RotateCcw className="w-3 h-3 mr-1" /> Restart
                      </Button>
                    </>
                  ) : (
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 text-xs text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10 px-2"
                      onClick={(e) => { e.stopPropagation(); startServer(server.id) }}
                    >
                      <Play className="w-3 h-3 mr-1" /> Start
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 text-xs text-muted-foreground hover:text-white hover:bg-white/[0.04] ml-auto px-2"
                    onClick={(e) => { e.stopPropagation(); navigateToServer(server.id) }}
                  >
                    Manage <ChevronRight className="w-3 h-3 ml-1" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}

          {servers.length === 0 && (
            <div className="col-span-full py-12 text-center">
              <ServerIcon className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
              <p className="text-muted-foreground">No servers found</p>
              <p className="text-xs text-muted-foreground/60 mt-1">Ask an admin to create a server for you.</p>
            </div>
          )}
        </div>
      </div>

      {/* Activity feed */}
      <div>
        <h2 className="text-lg font-semibold text-white mb-4">Recent Activity</h2>
        <Card className="bg-[#111318] border-white/[0.06]">
          <CardContent className="p-0">
            <div className="divide-y divide-white/[0.04]">
              {[
                { action: 'Server started', detail: 'Survival World is now online', time: '2 minutes ago', type: 'success' },
                { action: 'Backup completed', detail: 'Daily backup for Creative Hub', time: '1 hour ago', type: 'info' },
                { action: 'Player joined', detail: 'Steve joined Survival World', time: '2 hours ago', type: 'info' },
                { action: 'High CPU alert', detail: 'Bed Wars exceeded 80% CPU', time: '3 hours ago', type: 'warning' },
                { action: 'Server stopped', detail: 'Skyblock was stopped manually', time: '5 hours ago', type: 'error' },
              ].map((activity, i) => (
                <div key={i} className="flex items-center gap-3 px-5 py-3 hover:bg-white/[0.02] transition-colors">
                  <div className={cn(
                    "w-2 h-2 rounded-full flex-shrink-0",
                    activity.type === 'success' && 'bg-emerald-400',
                    activity.type === 'info' && 'bg-cyan-400',
                    activity.type === 'warning' && 'bg-amber-400',
                    activity.type === 'error' && 'bg-red-400',
                  )} />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm text-white truncate">{activity.action}</p>
                    <p className="text-xs text-muted-foreground truncate">{activity.detail}</p>
                  </div>
                  <span className="text-[10px] text-muted-foreground/60 flex-shrink-0">{activity.time}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
