'use client'

import { useEffect, useState } from 'react'
import { useAuthStore } from '@/stores/authStore'
import { useServerStore } from '@/stores/serverStore'
import { useUIStore, type PageId } from '@/stores/uiStore'
import { cn } from '@/lib/utils'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Shield,
  Users,
  Server,
  Settings,
  Plus,
  Trash2,
  Edit,
  Search,
  Activity,
  Cpu,
  MemoryStick,
  HardDrive,
  Check,
  X,
  UserPlus,
} from 'lucide-react'

type AdminTab = 'overview' | 'users' | 'servers' | 'settings'

export function AdminPage() {
  const { user } = useAuthStore()
  const { servers, fetchServers } = useServerStore()
  const { currentPage } = useUIStore()
  const [activeTab, setActiveTab] = useState<AdminTab>(
    currentPage === 'admin-settings' ? 'settings' : 
    currentPage === 'admin-servers' ? 'servers' : 
    currentPage === 'admin-users' ? 'users' : 'overview'
  )
  const [adminUsers, setAdminUsers] = useState<Array<Record<string, unknown>>>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [settings, setSettings] = useState<Record<string, string>>({
    panelName: 'MCPanel v2',
    panelDescription: 'Modern Minecraft Server Control Panel',
    registrationEnabled: 'true',
    defaultServerType: 'vanilla',
    defaultVersion: '1.21.4',
  })
  const [showCreateUser, setShowCreateUser] = useState(false)
  const [newUser, setNewUser] = useState({ username: '', email: '', password: '', role: 'user' })

  // Fetch admin data
  useEffect(() => {
    if (user?.role === 'admin') {
      fetch('/api/admin/users', {
        headers: { Authorization: `Bearer ${localStorage.getItem('mcpanel_token')}` },
      })
        .then(r => r.json())
        .then(data => {
          if (data.success) setAdminUsers(data.users)
        })
        .catch(() => {})

      fetch('/api/admin/settings', {
        headers: { Authorization: `Bearer ${localStorage.getItem('mcpanel_token')}` },
      })
        .then(r => r.json())
        .then(data => {
          if (data.success) setSettings(data.settings)
        })
        .catch(() => {})
    }
  }, [user])

  const handleCreateUser = async () => {
    try {
      const res = await fetch('/api/admin/users', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${localStorage.getItem('mcpanel_token')}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newUser),
      })
      const data = await res.json()
      if (data.success) {
        setAdminUsers(prev => [...prev, data.user])
        setShowCreateUser(false)
        setNewUser({ username: '', email: '', password: '', role: 'user' })
      }
    } catch (error) {
      console.error('Create user error:', error)
    }
  }

  const handleDeleteUser = async (userId: number) => {
    try {
      const res = await fetch(`/api/admin/users/${userId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${localStorage.getItem('mcpanel_token')}` },
      })
      const data = await res.json()
      if (data.success) {
        setAdminUsers(prev => prev.filter(u => (u as Record<string, unknown>).id !== userId))
      }
    } catch (error) {
      console.error('Delete user error:', error)
    }
  }

  const handleSaveSettings = async () => {
    try {
      await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${localStorage.getItem('mcpanel_token')}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(settings),
      })
    } catch (error) {
      console.error('Save settings error:', error)
    }
  }

  if (user?.role !== 'admin') {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <Shield className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground">Admin access required</p>
        </div>
      </div>
    )
  }

  const tabs = [
    { id: 'overview' as AdminTab, label: 'Overview', icon: Activity },
    { id: 'users' as AdminTab, label: 'Users', icon: Users },
    { id: 'servers' as AdminTab, label: 'Servers', icon: Server },
    { id: 'settings' as AdminTab, label: 'Settings', icon: Settings },
  ]

  const onlineServers = servers.filter(s => s.status === 'online')

  return (
    <div className="space-y-4 fade-in">
      {/* Tabs */}
      <div className="flex items-center gap-1 bg-[#111318] rounded-lg p-1 w-fit">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-md text-sm transition-all",
              activeTab === tab.id
                ? "bg-emerald-500/10 text-emerald-400"
                : "text-muted-foreground hover:text-white hover:bg-white/[0.04]"
            )}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { title: 'Total Users', value: adminUsers.length, icon: Users, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
              { title: 'Total Servers', value: servers.length, icon: Server, color: 'text-cyan-400', bg: 'bg-cyan-500/10' },
              { title: 'Online Servers', value: onlineServers.length, icon: Activity, color: 'text-green-400', bg: 'bg-green-500/10' },
              { title: 'System Health', value: 'Good', icon: Cpu, color: 'text-amber-400', bg: 'bg-amber-500/10' },
            ].map((stat) => (
              <Card key={stat.title} className="bg-[#111318] border-white/[0.06]">
                <CardContent className="p-5">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs text-muted-foreground font-medium">{stat.title}</p>
                      <p className="text-2xl font-bold text-white mt-1">{stat.value}</p>
                    </div>
                    <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center", stat.bg)}>
                      <stat.icon className={cn("w-5 h-5", stat.color)} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* System resources */}
          <Card className="bg-[#111318] border-white/[0.06]">
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">System Resources</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { label: 'CPU Usage', value: 34, icon: Cpu, color: 'bg-emerald-500' },
                { label: 'Memory Usage', value: 58, icon: MemoryStick, color: 'bg-cyan-500' },
                { label: 'Disk Usage', value: 42, icon: HardDrive, color: 'bg-purple-500' },
              ].map((item) => (
                <div key={item.label} className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <item.icon className="w-4 h-4 text-muted-foreground" />
                      <span className="text-muted-foreground">{item.label}</span>
                    </div>
                    <span className="text-white font-medium">{item.value}%</span>
                  </div>
                  <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
                    <div className={cn("h-full rounded-full transition-all", item.color)} style={{ width: `${item.value}%` }} />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      )}

      {/* Users Tab */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search users..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-[#111318] border-white/[0.06] text-white h-9"
              />
            </div>
            <Dialog open={showCreateUser} onOpenChange={setShowCreateUser}>
              <DialogTrigger asChild>
                <Button className="bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border-0">
                  <UserPlus className="w-4 h-4 mr-1.5" /> Add User
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-[#111318] border-white/10">
                <DialogHeader>
                  <DialogTitle className="text-white">Create New User</DialogTitle>
                </DialogHeader>
                <div className="space-y-3">
                  <Input placeholder="Username" value={newUser.username} onChange={e => setNewUser(p => ({ ...p, username: e.target.value }))} className="bg-[#0a0c10] border-white/10 text-white" />
                  <Input placeholder="Email" type="email" value={newUser.email} onChange={e => setNewUser(p => ({ ...p, email: e.target.value }))} className="bg-[#0a0c10] border-white/10 text-white" />
                  <Input placeholder="Password" type="password" value={newUser.password} onChange={e => setNewUser(p => ({ ...p, password: e.target.value }))} className="bg-[#0a0c10] border-white/10 text-white" />
                  <select
                    value={newUser.role}
                    onChange={e => setNewUser(p => ({ ...p, role: e.target.value }))}
                    className="w-full h-9 rounded-md bg-[#0a0c10] border border-white/10 text-white px-3 text-sm"
                  >
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                  </select>
                  <Button onClick={handleCreateUser} className="w-full bg-gradient-to-r from-emerald-500 to-cyan-500 text-black font-semibold">
                    Create User
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <Card className="bg-[#111318] border-white/[0.06]">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="border-white/[0.06] hover:bg-transparent">
                    <TableHead className="text-muted-foreground">User</TableHead>
                    <TableHead className="text-muted-foreground">Role</TableHead>
                    <TableHead className="text-muted-foreground hidden sm:table-cell">Status</TableHead>
                    <TableHead className="text-muted-foreground hidden md:table-cell">Created</TableHead>
                    <TableHead className="w-20" />
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {adminUsers
                    .filter(u => 
                      (u.username as string)?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      (u.email as string)?.toLowerCase().includes(searchQuery.toLowerCase())
                    )
                    .map((u) => (
                      <TableRow key={u.id as number} className="border-white/[0.03] hover:bg-white/[0.02]">
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 border border-white/10 flex items-center justify-center">
                              <span className="text-xs font-medium text-emerald-400">
                                {(u.username as string)?.charAt(0).toUpperCase()}
                              </span>
                            </div>
                            <div>
                              <p className="text-sm text-white font-medium">{u.displayName || u.username}</p>
                              <p className="text-xs text-muted-foreground">{u.email}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={cn(
                            "text-[10px] border-0",
                            u.role === 'admin' ? 'bg-amber-500/10 text-amber-400' : 'bg-white/5 text-muted-foreground'
                          )}>
                            {u.role as string}
                          </Badge>
                        </TableCell>
                        <TableCell className="hidden sm:table-cell">
                          <Badge className={cn(
                            "text-[10px] border-0",
                            u.status === 'active' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'
                          )}>
                            {u.status as string}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground hidden md:table-cell">
                          {new Date(u.createdAt as string).toLocaleDateString()}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-white">
                              <Edit className="w-3 h-3" />
                            </Button>
                            {(u.id as number) !== user?.id && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-7 w-7 text-muted-foreground hover:text-destructive"
                                onClick={() => handleDeleteUser(u.id as number)}
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Servers Tab */}
      {activeTab === 'servers' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm text-muted-foreground">All Servers</h3>
            <Button className="bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border-0">
              <Plus className="w-4 h-4 mr-1.5" /> New Server
            </Button>
          </div>
          <Card className="bg-[#111318] border-white/[0.06]">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="border-white/[0.06] hover:bg-transparent">
                    <TableHead className="text-muted-foreground">Server</TableHead>
                    <TableHead className="text-muted-foreground">Type</TableHead>
                    <TableHead className="text-muted-foreground">Status</TableHead>
                    <TableHead className="text-muted-foreground hidden sm:table-cell">Port</TableHead>
                    <TableHead className="w-20" />
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {servers.map((server) => (
                    <TableRow key={server.id} className="border-white/[0.03] hover:bg-white/[0.02]">
                      <TableCell>
                        <div>
                          <p className="text-sm text-white font-medium">{server.name}</p>
                          <p className="text-xs text-muted-foreground">v{server.version}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-[10px] border-0 bg-emerald-500/10 text-emerald-400">
                          {server.serverType}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5">
                          <span className={cn(
                            "w-1.5 h-1.5 rounded-full",
                            server.status === 'online' ? 'bg-emerald-400 pulse-dot' : 'bg-white/20'
                          )} />
                          <span className={cn(
                            "text-xs",
                            server.status === 'online' ? 'text-emerald-400' : 'text-muted-foreground'
                          )}>
                            {server.status}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground hidden sm:table-cell">
                        :{server.port}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-white">
                            <Edit className="w-3 h-3" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive">
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Settings Tab */}
      {activeTab === 'settings' && (
        <div className="space-y-4">
          <Card className="bg-[#111318] border-white/[0.06]">
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">Panel Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs text-muted-foreground font-medium">Panel Name</label>
                  <Input
                    value={settings.panelName || ''}
                    onChange={(e) => setSettings(prev => ({ ...prev, panelName: e.target.value }))}
                    className="bg-[#0a0c10] border-white/10 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs text-muted-foreground font-medium">Panel Description</label>
                  <Input
                    value={settings.panelDescription || ''}
                    onChange={(e) => setSettings(prev => ({ ...prev, panelDescription: e.target.value }))}
                    className="bg-[#0a0c10] border-white/10 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs text-muted-foreground font-medium">Default Server Type</label>
                  <select
                    value={settings.defaultServerType || 'vanilla'}
                    onChange={(e) => setSettings(prev => ({ ...prev, defaultServerType: e.target.value }))}
                    className="w-full h-9 rounded-md bg-[#0a0c10] border border-white/10 text-white px-3 text-sm"
                  >
                    <option value="vanilla">Vanilla</option>
                    <option value="spigot">Spigot</option>
                    <option value="paper">Paper</option>
                    <option value="purpur">Purpur</option>
                    <option value="forge">Forge</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-xs text-muted-foreground font-medium">Default Version</label>
                  <Input
                    value={settings.defaultVersion || ''}
                    onChange={(e) => setSettings(prev => ({ ...prev, defaultVersion: e.target.value }))}
                    className="bg-[#0a0c10] border-white/10 text-white"
                  />
                </div>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-white/[0.02] border border-white/[0.04]">
                <div>
                  <p className="text-sm text-white">Enable Registration</p>
                  <p className="text-xs text-muted-foreground">Allow new users to create accounts</p>
                </div>
                <button
                  onClick={() => setSettings(prev => ({ ...prev, registrationEnabled: prev.registrationEnabled === 'true' ? 'false' : 'true' }))}
                  className={cn(
                    "w-10 h-5 rounded-full transition-colors relative",
                    settings.registrationEnabled === 'true' ? 'bg-emerald-500' : 'bg-white/10'
                  )}
                >
                  <span className={cn(
                    "absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform shadow-sm",
                    settings.registrationEnabled === 'true' ? 'translate-x-5' : 'translate-x-0.5'
                  )} />
                </button>
              </div>
              <Button onClick={handleSaveSettings} className="bg-gradient-to-r from-emerald-500 to-cyan-500 text-black font-semibold">
                Save Settings
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
