'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import { io, Socket } from 'socket.io-client'
import { useServerStore } from '@/stores/serverStore'
import { useUIStore } from '@/stores/uiStore'
import { cn } from '@/lib/utils'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  Terminal,
  Send,
  Trash2,
  ArrowDown,
  Search,
  Zap,
} from 'lucide-react'

interface ConsoleLine {
  id: number
  text: string
  type: 'info' | 'warn' | 'error' | 'success' | 'command'
}

function parseLogType(text: string): ConsoleLine['type'] {
  if (text.includes('/WARN') || text.includes('[WARN]')) return 'warn'
  if (text.includes('/ERROR') || text.includes('[ERROR]') || text.includes('Exception') || text.includes('Caused by')) return 'error'
  if (text.includes('Done') || text.includes('joined') || text.includes('earned')) return 'success'
  if (text.startsWith('>')) return 'command'
  return 'info'
}

const quickCommands = [
  { label: 'help', command: 'help' },
  { label: 'list', command: 'list' },
  { label: 'say hi', command: 'say Hello everyone!' },
  { label: 'time set day', command: 'time set day' },
  { label: 'time set night', command: 'time set night' },
  { label: 'weather clear', command: 'weather clear' },
  { label: 'gamemode creative', command: 'gamemode creative' },
  { label: 'gamemode survival', command: 'gamemode survival' },
]

export function ConsolePage() {
  const { servers, selectedServerId, sendCommand, startServer, serverStats } = useServerStore()
  const { navigateToServer } = useUIStore()
  const server = servers.find(s => s.id === selectedServerId)
  const stats = selectedServerId ? serverStats.get(selectedServerId) : null

  const [lines, setLines] = useState<ConsoleLine[]>([])
  const [input, setInput] = useState('')
  const [commandHistory, setCommandHistory] = useState<string[]>([])
  const [historyIndex, setHistoryIndex] = useState(-1)
  const [autoScroll, setAutoScroll] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [showSearch, setShowSearch] = useState(false)
  const [isConnected, setIsConnected] = useState(false)

  const consoleRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const socketRef = useRef<Socket | null>(null)
  const lineIdRef = useRef(0)

  // Connect to Socket.IO
  useEffect(() => {
    if (!selectedServerId) return

    const socket = io('/?XTransformPort=3003', {
      transports: ['websocket', 'polling'],
    })

    socket.on('connect', () => {
      setIsConnected(true)
      socket.emit('join-server', { serverId: selectedServerId })
    })

    socket.on('disconnect', () => {
      setIsConnected(false)
    })

    socket.on('console-output', (data: { serverId: number; line: string }) => {
      if (data.serverId === selectedServerId) {
        const type = parseLogType(data.line)
        setLines(prev => [...prev.slice(-500), { id: lineIdRef.current++, text: data.line, type }])
      }
    })

    socket.on('server-status-change', (data: { serverId: number; status: string }) => {
      if (data.serverId === selectedServerId) {
        // Status changes are handled via store
      }
    })

    socketRef.current = socket

    return () => {
      socket.emit('leave-server', { serverId: selectedServerId })
      socket.disconnect()
    }
  }, [selectedServerId])

  // Auto-scroll
  useEffect(() => {
    if (autoScroll && consoleRef.current) {
      consoleRef.current.scrollTop = consoleRef.current.scrollHeight
    }
  }, [lines, autoScroll])

  const handleCommand = useCallback(async (cmd: string) => {
    if (!cmd.trim() || !selectedServerId) return

    // Add to local history
    const type = parseLogType(`> ${cmd}`)
    setLines(prev => [...prev, { id: lineIdRef.current++, text: `> ${cmd}`, type: 'command' }])
    setCommandHistory(prev => [cmd, ...prev.slice(0, 49)])
    setHistoryIndex(-1)

    // Send via socket
    if (socketRef.current?.connected) {
      socketRef.current.emit('server-command', { serverId: selectedServerId, command: cmd })
    }

    // Also send via API for persistence
    await sendCommand(selectedServerId, cmd)
    setInput('')
  }, [selectedServerId, sendCommand])

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleCommand(input)
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      if (commandHistory.length > 0) {
        const newIndex = Math.min(historyIndex + 1, commandHistory.length - 1)
        setHistoryIndex(newIndex)
        setInput(commandHistory[newIndex])
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault()
      if (historyIndex > 0) {
        const newIndex = historyIndex - 1
        setHistoryIndex(newIndex)
        setInput(commandHistory[newIndex])
      } else {
        setHistoryIndex(-1)
        setInput('')
      }
    }
  }

  const filteredLines = searchQuery
    ? lines.filter(l => l.text.toLowerCase().includes(searchQuery.toLowerCase()))
    : lines

  if (!server) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <Terminal className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground">No server selected</p>
          <Button variant="ghost" className="mt-2 text-emerald-400" onClick={() => navigateToServer(0, 'dashboard')}>
            Go to Dashboard
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] fade-in">
      {/* Console header */}
      <div className="flex items-center justify-between mb-3 flex-shrink-0">
        <div className="flex items-center gap-3">
          <Badge variant="outline" className={cn(
            "text-[10px] border-0",
            isConnected ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'
          )}>
            <span className={cn(
              "w-1.5 h-1.5 rounded-full mr-1 inline-block",
              isConnected ? 'bg-emerald-400 pulse-dot' : 'bg-red-400'
            )} />
            {isConnected ? 'Connected' : 'Disconnected'}
          </Badge>
          <Badge variant="outline" className="text-[10px] border-0 bg-white/5 text-muted-foreground">
            {lines.length} lines
          </Badge>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-muted-foreground hover:text-white"
            onClick={() => setShowSearch(!showSearch)}
          >
            <Search className="w-3.5 h-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className={cn(
              "h-7 w-7",
              autoScroll ? "text-emerald-400 hover:text-emerald-300" : "text-muted-foreground hover:text-white"
            )}
            onClick={() => setAutoScroll(!autoScroll)}
          >
            <ArrowDown className="w-3.5 h-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-muted-foreground hover:text-white"
            onClick={() => setLines([])}
          >
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      {/* Search bar */}
      {showSearch && (
        <div className="mb-3 flex-shrink-0">
          <Input
            placeholder="Search console output..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="h-8 text-xs bg-[#0a0c10] border-white/10 text-white"
          />
        </div>
      )}

      {/* Console output */}
      <Card className="flex-1 bg-[#0a0c10] border-white/[0.06] overflow-hidden min-h-0">
        <CardContent className="p-0 h-full">
          <div
            ref={consoleRef}
            className="h-full overflow-y-auto p-4 console-output"
            onClick={() => inputRef.current?.focus()}
          >
            {filteredLines.length === 0 ? (
              <div className="flex items-center justify-center h-full text-muted-foreground/40">
                <div className="text-center">
                  <Terminal className="w-8 h-8 mx-auto mb-2" />
                  <p className="text-sm">
                    {server.status === 'online'
                      ? 'Waiting for console output...'
                      : 'Start the server to see console output'}
                  </p>
                </div>
              </div>
            ) : (
              filteredLines.map((line) => (
                <div
                  key={line.id}
                  className={cn(
                    "py-0.5 leading-relaxed whitespace-pre-wrap break-all",
                    line.type === 'warn' && 'text-amber-400',
                    line.type === 'error' && 'text-red-400',
                    line.type === 'success' && 'text-emerald-400',
                    line.type === 'command' && 'text-cyan-400',
                    line.type === 'info' && 'text-slate-400',
                  )}
                >
                  {line.text}
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Quick commands */}
      <div className="mt-3 flex gap-1.5 overflow-x-auto pb-1 flex-shrink-0">
        {quickCommands.map((cmd) => (
          <Button
            key={cmd.label}
            variant="outline"
            size="sm"
            className="h-7 text-[11px] border-white/10 text-muted-foreground hover:text-white hover:bg-white/[0.04] flex-shrink-0 px-2.5"
            onClick={() => handleCommand(cmd.command)}
          >
            <Zap className="w-3 h-3 mr-1" />
            {cmd.label}
          </Button>
        ))}
      </div>

      {/* Command input */}
      <div className="mt-3 flex gap-2 flex-shrink-0">
        <div className="flex-1 relative">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-emerald-400 font-mono text-sm">&gt;</span>
          <Input
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={server.status === 'online' ? 'Type a command...' : 'Server is offline'}
            disabled={server.status !== 'online'}
            className="pl-8 bg-[#0a0c10] border-white/10 text-white font-mono text-sm placeholder:text-muted-foreground/40"
          />
        </div>
        <Button
          onClick={() => handleCommand(input)}
          disabled={!input.trim() || server.status !== 'online'}
          className="bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border-0"
        >
          <Send className="w-4 h-4" />
        </Button>
      </div>
    </div>
  )
}
