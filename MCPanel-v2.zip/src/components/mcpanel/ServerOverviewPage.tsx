'use client'

import { useEffect, useState } from 'react'
import { useServerStore } from '@/stores/serverStore'
import { useUIStore } from '@/stores/uiStore'
import { cn } from '@/lib/utils'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import {
  Server,
  Play,
  Square,
  RotateCcw,
  Cpu,
  MemoryStick,
  HardDrive,
  Users,
  Globe,
  Clock,
  Terminal,
  ChevronRight,
  Wifi,
  WifiOff,
} from 'lucide-react'

export function ServerOverviewPage() {
  const { servers, selectedServerId, serverStats, selectServer, startServer, stopServer } = useServerStore()
  const { navigateToServer } = useUIStore()
  const [loading, setLoading] = useState(true)

  const server = servers.find(s => s.id === selectedServerId)
  const stats = selectedServerId ? serverStats.get(selectedServerId) : null

  useEffect(() => {
    if (selectedServerId) {
      selectServer(selectedServerId).finally(() => setLoading(false))
    }
  }, [selectedServerId, selectServer])

  if (!server) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <Server className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground">No server selected</p>
          <Button variant="ghost" className="mt-2 text-emerald-400" onClick={() => navigateToServer(0, 'dashboard')}>
            Go to Dashboard
          </Button>
        </div>
      </div>
    )
  }

  const isOnline = server.status === 'online'

  const resourceCards = [
    {
      title: 'CPU',
      value: stats?.cpu ?? (isOnline ? 45 : 0),
      unit: '%',
      icon: Cpu,
      color: stats?.cpu && stats.cpu > 80 ? 'text-red-400' : stats?.cpu && stats.cpu > 60 ? 'text-amber-400' : 'text-emerald-400',
      barColor: stats?.cpu && stats.cpu > 80 ? 'bg-red-500' : stats?.cpu && stats.cpu > 60 ? 'bg-amber-500' : 'bg-emerald-500',
    },
    {
      title: 'RAM',
      value: stats?.ram ?? (isOnline ? 62 : 0),
      unit: '%',
      icon: MemoryStick,
      color: stats?.ram && stats.ram > 80 ? 'text-red-400' : stats?.ram && stats.ram > 60 ? 'text-amber-400' : 'text-cyan-400',
      barColor: stats?.ram && stats.ram > 80 ? 'bg-red-500' : stats?.ram && stats.ram > 60 ? 'bg-amber-500' : 'bg-cyan-500',
    },
    {
      title: 'Disk',
      value: stats?.disk ?? (isOnline ? 35 : 0),
      unit: '%',
      icon: HardDrive,
      color: 'text-purple-400',
      barColor: 'bg-purple-500',
    },
    {
      title: 'Players',
      value: stats?.playerCount ?? (isOnline ? 3 : 0),
      unit: '/20',
      icon: Users,
      color: 'text-amber-400',
      barColor: 'bg-amber-500',
      max: 20,
    },
  ]

  return (
    <div className="space-y-6 fade-in">
      {/* Server header */}
      <div className="glass rounded-xl p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className={cn(
              "w-14 h-14 rounded-xl flex items-center justify-center",
              isOnline ? 'bg-emerald-500/10' : 'bg-white/5'
            )}>
              <Server className={cn("w-7 h-7", isOnline ? 'text-emerald-400' : 'text-muted-foreground')} />
            </div>
            <div>
              <div className="flex items-center gap-3">
                <h1 className="text-2xl font-bold text-white">{server.name}</h1>
                <Badge className={cn(
                  "text-[10px] border-0",
                  isOnline ? 'bg-emerald-500/10 text-emerald-400' : 'bg-white/5 text-muted-foreground'
                )}>
                  <span className={cn(
                    "w-1.5 h-1.5 rounded-full mr-1 inline-block",
                    isOnline ? 'bg-emerald-400 pulse-dot' : 'bg-muted-foreground/50'
                  )} />
                  {server.status}
                </Badge>
              </div>
              <div className="flex items-center gap-3 mt-1">
                <Badge variant="outline" className="text-[10px] border-0 bg-emerald-500/10 text-emerald-400">
                  {server.serverType}
                </Badge>
                <Badge variant="outline" className="text-[10px] border-0 bg-white/5 text-muted-foreground">
                  v{server.version}
                </Badge>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isOnline ? (
              <>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-white/10 text-destructive hover:text-destructive hover:bg-destructive/10"
                  onClick={() => stopServer(server.id)}
                >
                  <Square className="w-3.5 h-3.5 mr-1.5" /> Stop
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-white/10 text-amber-400 hover:text-amber-300 hover:bg-amber-500/10"
                >
                  <RotateCcw className="w-3.5 h-3.5 mr-1.5" /> Restart
                </Button>
                <Button
                  size="sm"
                  className="bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border-0"
                  onClick={() => navigateToServer(server.id, 'console')}
                >
                  <Terminal className="w-3.5 h-3.5 mr-1.5" /> Console
                </Button>
              </>
            ) : (
              <Button
                size="sm"
                className="bg-gradient-to-r from-emerald-500 to-cyan-500 text-black font-semibold shadow-lg shadow-emerald-500/20"
                onClick={() => startServer(server.id)}
              >
                <Play className="w-3.5 h-3.5 mr-1.5" /> Start Server
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Resource usage cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {resourceCards.map((card) => (
          <Card key={card.title} className="bg-[#111318] border-white/[0.06]">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <card.icon className={cn("w-4 h-4", card.color)} />
                  <span className="text-xs text-muted-foreground font-medium">{card.title}</span>
                </div>
              </div>
              <div className="flex items-baseline gap-1 mb-3">
                <span className="text-3xl font-bold text-white">{card.value}</span>
                <span className="text-sm text-muted-foreground">{card.unit}</span>
              </div>
              <Progress
                value={card.max ? (card.value / card.max) * 100 : card.value}
                className="h-2 bg-white/5"
              />
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Server info & Quick access */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Server Info */}
        <Card className="bg-[#111318] border-white/[0.06]">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Server Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {[
              { label: 'Server Type', value: server.serverType, icon: Server },
              { label: 'Version', value: server.version, icon: Globe },
              { label: 'Port', value: String(server.port), icon: Wifi },
              { label: 'RAM', value: `${server.ram} MB`, icon: MemoryStick },
              { label: 'CPU Cores', value: String(server.cpu), icon: Cpu },
              { label: 'Disk', value: `${(server.disk / 1024).toFixed(1)} GB`, icon: HardDrive },
              { label: 'Created', value: new Date(server.createdAt).toLocaleDateString(), icon: Clock },
              { label: 'Owner', value: server.owner?.displayName || server.owner?.username || 'Unknown', icon: Users },
            ].map((item) => (
              <div key={item.label} className="flex items-center justify-between py-1.5">
                <div className="flex items-center gap-2">
                  <item.icon className="w-3.5 h-3.5 text-muted-foreground/60" />
                  <span className="text-sm text-muted-foreground">{item.label}</span>
                </div>
                <span className="text-sm text-white font-medium">{item.value}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Quick access */}
        <Card className="bg-[#111318] border-white/[0.06]">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Quick Access</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {[
              { label: 'Console', desc: 'View server console and send commands', icon: Terminal, page: 'console' as const },
              { label: 'File Manager', desc: 'Browse and manage server files', icon: HardDrive, page: 'files' as const },
              { label: 'Players', desc: 'View and manage online players', icon: Users, page: 'players' as const },
              { label: 'Backups', desc: 'Create and restore server backups', icon: HardDrive, page: 'backups' as const },
            ].map((item) => (
              <button
                key={item.label}
                onClick={() => navigateToServer(server.id, item.page)}
                className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-white/[0.03] transition-colors group"
              >
                <div className="w-9 h-9 rounded-lg bg-white/[0.04] flex items-center justify-center group-hover:bg-emerald-500/10 transition-colors">
                  <item.icon className="w-4 h-4 text-muted-foreground group-hover:text-emerald-400 transition-colors" />
                </div>
                <div className="text-left flex-1">
                  <p className="text-sm text-white group-hover:text-emerald-400 transition-colors">{item.label}</p>
                  <p className="text-xs text-muted-foreground">{item.desc}</p>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground/40 group-hover:text-emerald-400 transition-colors" />
              </button>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
