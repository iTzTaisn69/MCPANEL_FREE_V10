'use client'

import { useState } from 'react'
import { useServerStore } from '@/stores/serverStore'
import { useUIStore } from '@/stores/uiStore'
import { cn } from '@/lib/utils'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  FolderOpen,
  File,
  FileCode,
  FileText,
  Image,
  Archive,
  ChevronRight,
  Upload,
  Download,
  Trash2,
  Edit,
  FolderPlus,
  Home,
  RefreshCw,
  Search,
} from 'lucide-react'

interface FileEntry {
  name: string
  type: 'file' | 'folder'
  size: string
  modified: string
  extension?: string
}

// Mock file system
const mockFileSystem: Record<string, FileEntry[]> = {
  '/': [
    { name: 'server.jar', type: 'file', size: '45.2 MB', modified: '2024-12-15', extension: 'jar' },
    { name: 'eula.txt', type: 'file', size: '153 B', modified: '2024-12-15', extension: 'txt' },
    { name: 'server.properties', type: 'file', size: '1.2 KB', modified: '2024-12-20', extension: 'properties' },
    { name: 'banned-players.json', type: 'file', size: '2.1 KB', modified: '2024-12-18', extension: 'json' },
    { name: 'banned-ips.json', type: 'file', size: '48 B', modified: '2024-12-15', extension: 'json' },
    { name: 'ops.json', type: 'file', size: '324 B', modified: '2024-12-16', extension: 'json' },
    { name: 'whitelist.json', type: 'file', size: '156 B', modified: '2024-12-15', extension: 'json' },
    { name: 'world', type: 'folder', size: '-', modified: '2024-12-21' },
    { name: 'world_nether', type: 'folder', size: '-', modified: '2024-12-21' },
    { name: 'world_the_end', type: 'folder', size: '-', modified: '2024-12-21' },
    { name: 'plugins', type: 'folder', size: '-', modified: '2024-12-19' },
    { name: 'logs', type: 'folder', size: '-', modified: '2024-12-21' },
    { name: 'crash-reports', type: 'folder', size: '-', modified: '2024-12-17' },
  ],
  '/world': [
    { name: 'level.dat', type: 'file', size: '12.4 KB', modified: '2024-12-21', extension: 'dat' },
    { name: 'session.lock', type: 'file', size: '8 B', modified: '2024-12-21', extension: 'lock' },
    { name: 'region', type: 'folder', size: '-', modified: '2024-12-21' },
    { name: 'playerdata', type: 'folder', size: '-', modified: '2024-12-21' },
    { name: 'data', type: 'folder', size: '-', modified: '2024-12-21' },
  ],
  '/plugins': [
    { name: 'EssentialsX-2.20.1.jar', type: 'file', size: '2.4 MB', modified: '2024-12-19', extension: 'jar' },
    { name: 'WorldEdit-7.2.18.jar', type: 'file', size: '6.8 MB', modified: '2024-12-18', extension: 'jar' },
    { name: 'LuckPerms-Bukkit-5.4.108.jar', type: 'file', size: '3.2 MB', modified: '2024-12-17', extension: 'jar' },
    { name: 'Vault.jar', type: 'file', size: '456 KB', modified: '2024-12-16', extension: 'jar' },
  ],
  '/logs': [
    { name: 'latest.log', type: 'file', size: '234 KB', modified: '2024-12-21', extension: 'log' },
    { name: '2024-12-20-1.log.gz', type: 'file', size: '89 KB', modified: '2024-12-20', extension: 'gz' },
    { name: '2024-12-19-1.log.gz', type: 'file', size: '76 KB', modified: '2024-12-19', extension: 'gz' },
    { name: '2024-12-18-1.log.gz', type: 'file', size: '92 KB', modified: '2024-12-18', extension: 'gz' },
  ],
}

function getFileIcon(entry: FileEntry) {
  if (entry.type === 'folder') return FolderOpen
  const ext = entry.extension?.toLowerCase()
  if (ext === 'jar' || ext === 'gz' || ext === 'zip') return Archive
  if (ext === 'json' || ext === 'properties' || ext === 'yml' || ext === 'yaml') return FileCode
  if (ext === 'txt' || ext === 'log') return FileText
  if (ext === 'png' || ext === 'jpg' || ext === 'jpeg' || ext === 'gif') return Image
  return File
}

export function FileManagerPage() {
  const { servers, selectedServerId } = useServerStore()
  const { navigateToServer } = useUIStore()
  const server = servers.find(s => s.id === selectedServerId)

  const [currentPath, setCurrentPath] = useState('/')
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedFile, setSelectedFile] = useState<string | null>(null)

  const files = mockFileSystem[currentPath] || []
  const filteredFiles = searchQuery
    ? files.filter(f => f.name.toLowerCase().includes(searchQuery.toLowerCase()))
    : files

  const navigateToFolder = (folderName: string) => {
    const newPath = currentPath === '/' ? `/${folderName}` : `${currentPath}/${folderName}`
    setCurrentPath(newPath)
    setSelectedFile(null)
  }

  const navigateUp = () => {
    if (currentPath === '/') return
    const parts = currentPath.split('/')
    parts.pop()
    setCurrentPath(parts.join('/') || '/')
    setSelectedFile(null)
  }

  const pathParts = currentPath.split('/').filter(Boolean)

  if (!server) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <FolderOpen className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground">No server selected</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4 fade-in">
      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
        <div className="flex items-center gap-1.5">
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground" onClick={() => setCurrentPath('/')}>
            <Home className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground" onClick={navigateUp} disabled={currentPath === '/'}>
            <ChevronRight className="w-4 h-4 rotate-180" />
          </Button>
          
          {/* Breadcrumb */}
          <div className="flex items-center gap-1 text-sm">
            <button onClick={() => setCurrentPath('/')} className="text-emerald-400 hover:text-emerald-300">/</button>
            {pathParts.map((part, i) => (
              <span key={i} className="flex items-center gap-1">
                <ChevronRight className="w-3 h-3 text-muted-foreground/40" />
                <button
                  onClick={() => setCurrentPath('/' + pathParts.slice(0, i + 1).join('/'))}
                  className={cn(
                    "hover:text-emerald-300",
                    i === pathParts.length - 1 ? 'text-white font-medium' : 'text-emerald-400'
                  )}
                >
                  {part}
                </button>
              </span>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 sm:ml-auto">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              placeholder="Search files..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-8 w-48 text-xs pl-8 bg-[#0a0c10] border-white/10 text-white"
            />
          </div>
          <Button variant="outline" size="sm" className="h-8 border-white/10 text-muted-foreground hover:text-white">
            <FolderPlus className="w-3.5 h-3.5 mr-1.5" /> Folder
          </Button>
          <Button variant="outline" size="sm" className="h-8 border-white/10 text-muted-foreground hover:text-white">
            <Upload className="w-3.5 h-3.5 mr-1.5" /> Upload
          </Button>
        </div>
      </div>

      {/* File listing */}
      <Card className="bg-[#111318] border-white/[0.06]">
        <CardContent className="p-0">
          {/* Header */}
          <div className="flex items-center gap-4 px-4 py-2.5 border-b border-white/[0.04] text-xs text-muted-foreground font-medium">
            <span className="w-8" />
            <span className="flex-1">Name</span>
            <span className="w-24 text-right hidden sm:block">Size</span>
            <span className="w-28 text-right hidden md:block">Modified</span>
            <span className="w-24" />
          </div>

          {/* Files */}
          <div className="divide-y divide-white/[0.03]">
            {currentPath !== '/' && (
              <button
                onClick={navigateUp}
                className="w-full flex items-center gap-4 px-4 py-2.5 hover:bg-white/[0.02] transition-colors"
              >
                <span className="w-8 flex justify-center">
                  <ChevronRight className="w-4 h-4 text-muted-foreground rotate-180" />
                </span>
                <span className="flex-1 text-sm text-muted-foreground">..</span>
              </button>
            )}

            {filteredFiles.map((file) => {
              const Icon = getFileIcon(file)
              const isSelected = selectedFile === file.name

              return (
                <button
                  key={file.name}
                  onClick={() => {
                    if (file.type === 'folder') {
                      navigateToFolder(file.name)
                    } else {
                      setSelectedFile(isSelected ? null : file.name)
                    }
                  }}
                  className={cn(
                    "w-full flex items-center gap-4 px-4 py-2.5 hover:bg-white/[0.02] transition-colors group",
                    isSelected && "bg-emerald-500/5"
                  )}
                >
                  <span className="w-8 flex justify-center">
                    <Icon className={cn(
                      "w-4 h-4",
                      file.type === 'folder' ? 'text-emerald-400' :
                      file.extension === 'jar' ? 'text-amber-400' :
                      file.extension === 'json' || file.extension === 'properties' ? 'text-cyan-400' :
                      file.extension === 'log' || file.extension === 'gz' ? 'text-purple-400' :
                      'text-muted-foreground'
                    )} />
                  </span>
                  <span className={cn(
                    "flex-1 text-sm text-left truncate",
                    file.type === 'folder' ? 'text-white font-medium' : 'text-slate-300'
                  )}>
                    {file.name}
                  </span>
                  <span className="w-24 text-right text-xs text-muted-foreground hidden sm:block">{file.size}</span>
                  <span className="w-28 text-right text-xs text-muted-foreground/60 hidden md:block">{file.modified}</span>
                  <span className="w-24 flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    {file.type === 'file' && (
                      <>
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-white">
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-white">
                          <Download className="w-3 h-3" />
                        </Button>
                      </>
                    )}
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive">
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </span>
                </button>
              )
            })}

            {filteredFiles.length === 0 && (
              <div className="py-12 text-center text-muted-foreground text-sm">
                No files found
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
