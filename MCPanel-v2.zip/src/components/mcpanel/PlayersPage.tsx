'use client'

import { useEffect, useState } from 'react'
import { useServerStore } from '@/stores/serverStore'
import { useUIStore } from '@/stores/uiStore'
import { cn } from '@/lib/utils'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import {
  Users,
  Shield,
  ShieldOff,
  UserPlus,
  UserMinus,
  Crown,
  Search,
  Gamepad2,
} from 'lucide-react'

const mockOnlinePlayers = [
  { name: 'Steve', uuid: '8667ba71b85a4004af54457a9734eed7', joinedAgo: '2h 15m', gamemode: 'Survival', op: true },
  { name: 'Alex', uuid: '853c80ef3c3749fdaa49938b674adae6', joinedAgo: '1h 42m', gamemode: 'Survival', op: false },
  { name: 'Notch', uuid: '069a79f444e94726a5befca90e38aaf5', joinedAgo: '45m', gamemode: 'Creative', op: true },
  { name: 'Dream', uuid: 'ec70bcaf702f4bb8b48d276fa52a780c', joinedAgo: '32m', gamemode: 'Survival', op: false },
  { name: 'Philza', uuid: '01e5c4e2e9f54c3b9c7c9e3c5a5b6c7d', joinedAgo: '18m', gamemode: 'Hardcore', op: false },
]

const mockWhitelist = ['Steve', 'Alex', 'Notch', 'Dream', 'Philza', 'Technoblade', 'TommyInnit', 'Tubbo']
const mockBanned = ['Griefer123', 'Hacker_X']

export function PlayersPage() {
  const { servers, selectedServerId, serverStats } = useServerStore()
  const { navigateToServer } = useUIStore()
  const server = servers.find(s => s.id === selectedServerId)
  const stats = selectedServerId ? serverStats.get(selectedServerId) : null

  const [activeTab, setActiveTab] = useState<'online' | 'whitelist' | 'banned'>('online')
  const [searchQuery, setSearchQuery] = useState('')

  const onlinePlayers = stats?.players || mockOnlinePlayers.map(p => p.name)
  const isOnline = server?.status === 'online'

  if (!server) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <Users className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground">No server selected</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4 fade-in">
      {/* Tabs */}
      <div className="flex items-center gap-1 bg-[#111318] rounded-lg p-1 w-fit">
        {[
          { id: 'online' as const, label: 'Online', icon: Users, count: onlinePlayers.length },
          { id: 'whitelist' as const, label: 'Whitelist', icon: Shield, count: mockWhitelist.length },
          { id: 'banned' as const, label: 'Banned', icon: ShieldOff, count: mockBanned.length },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-md text-sm transition-all",
              activeTab === tab.id
                ? "bg-emerald-500/10 text-emerald-400"
                : "text-muted-foreground hover:text-white hover:bg-white/[0.04]"
            )}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
            <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 border-0 bg-white/5">
              {tab.count}
            </Badge>
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search players..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10 bg-[#111318] border-white/[0.06] text-white"
        />
      </div>

      {/* Content based on tab */}
      {activeTab === 'online' && (
        <Card className="bg-[#111318] border-white/[0.06]">
          <CardContent className="p-0">
            {isOnline ? (
              <div className="divide-y divide-white/[0.03]">
                {mockOnlinePlayers
                  .filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()))
                  .map((player) => (
                    <div key={player.uuid} className="flex items-center gap-4 px-5 py-3 hover:bg-white/[0.02] transition-colors group">
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={`https://crafatar.com/avatars/${player.uuid}?size=32&overlay`} alt={player.name} />
                        <AvatarFallback className="bg-emerald-500/10 text-emerald-400 text-xs">
                          {player.name.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-white font-medium">{player.name}</span>
                          {player.op && <Crown className="w-3 h-3 text-amber-400" />}
                        </div>
                        <div className="flex items-center gap-3 mt-0.5">
                          <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 border-0 bg-white/5 text-muted-foreground">
                            <Gamepad2 className="w-2.5 h-2.5 mr-1" />
                            {player.gamemode}
                          </Badge>
                          <span className="text-[10px] text-muted-foreground/60">Joined {player.joinedAgo} ago</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button variant="ghost" size="sm" className="h-7 text-xs text-amber-400 hover:text-amber-300 hover:bg-amber-500/10 px-2">
                          <Shield className="w-3 h-3 mr-1" /> OP
                        </Button>
                        <Button variant="ghost" size="sm" className="h-7 text-xs text-destructive hover:bg-destructive/10 px-2">
                          <UserMinus className="w-3 h-3 mr-1" /> Kick
                        </Button>
                      </div>
                    </div>
                  ))}
                {mockOnlinePlayers.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase())).length === 0 && (
                  <div className="py-12 text-center text-muted-foreground text-sm">No players found</div>
                )}
              </div>
            ) : (
              <div className="py-16 text-center">
                <Users className="w-12 h-12 text-muted-foreground/20 mx-auto mb-3" />
                <p className="text-muted-foreground">Server is offline</p>
                <p className="text-xs text-muted-foreground/60 mt-1">Start the server to see online players</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {activeTab === 'whitelist' && (
        <Card className="bg-[#111318] border-white/[0.06]">
          <CardContent className="p-0">
            <div className="px-5 py-3 border-b border-white/[0.04]">
              <Button variant="outline" size="sm" className="h-7 text-xs border-white/10 text-emerald-400 hover:text-emerald-300">
                <UserPlus className="w-3 h-3 mr-1.5" /> Add Player
              </Button>
            </div>
            <div className="divide-y divide-white/[0.03]">
              {mockWhitelist
                .filter(p => p.toLowerCase().includes(searchQuery.toLowerCase()))
                .map((player, i) => (
                  <div key={i} className="flex items-center gap-4 px-5 py-3 hover:bg-white/[0.02] transition-colors group">
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className="bg-white/5 text-muted-foreground text-xs">
                        {player.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-sm text-white flex-1">{player}</span>
                    <Button variant="ghost" size="sm" className="h-7 text-xs text-destructive hover:bg-destructive/10 opacity-0 group-hover:opacity-100 px-2">
                      <UserMinus className="w-3 h-3 mr-1" /> Remove
                    </Button>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === 'banned' && (
        <Card className="bg-[#111318] border-white/[0.06]">
          <CardContent className="p-0">
            <div className="px-5 py-3 border-b border-white/[0.04]">
              <Button variant="outline" size="sm" className="h-7 text-xs border-white/10 text-destructive hover:text-red-300">
                <ShieldOff className="w-3 h-3 mr-1.5" /> Ban Player
              </Button>
            </div>
            <div className="divide-y divide-white/[0.03]">
              {mockBanned
                .filter(p => p.toLowerCase().includes(searchQuery.toLowerCase()))
                .map((player, i) => (
                  <div key={i} className="flex items-center gap-4 px-5 py-3 hover:bg-white/[0.02] transition-colors group">
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className="bg-destructive/10 text-destructive text-xs">
                        {player.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-sm text-white flex-1">{player}</span>
                    <Badge variant="outline" className="text-[10px] border-0 bg-destructive/10 text-destructive">Banned</Badge>
                    <Button variant="ghost" size="sm" className="h-7 text-xs text-emerald-400 hover:bg-emerald-500/10 opacity-0 group-hover:opacity-100 px-2">
                      Unban
                    </Button>
                  </div>
                ))}
              {mockBanned.length === 0 && (
                <div className="py-12 text-center text-muted-foreground text-sm">No banned players</div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
