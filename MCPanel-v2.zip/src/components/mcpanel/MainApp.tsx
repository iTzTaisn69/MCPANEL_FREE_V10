'use client'

import { useEffect } from 'react'
import { useAuthStore } from '@/stores/authStore'
import { useServerStore } from '@/stores/serverStore'
import { useUIStore, type PageId } from '@/stores/uiStore'
import { Sidebar } from '@/components/mcpanel/Sidebar'
import { Header } from '@/components/mcpanel/Header'
import { DashboardPage } from '@/components/mcpanel/DashboardPage'
import { ServerOverviewPage } from '@/components/mcpanel/ServerOverviewPage'
import { ConsolePage } from '@/components/mcpanel/ConsolePage'
import { FileManagerPage } from '@/components/mcpanel/FileManagerPage'
import { PlayersPage } from '@/components/mcpanel/PlayersPage'
import { BackupsPage } from '@/components/mcpanel/BackupsPage'
import { AdminPage } from '@/components/mcpanel/AdminPage'
import { ProfilePage } from '@/components/mcpanel/ProfilePage'

export function MainApp() {
  const { user } = useAuthStore()
  const { fetchServers } = useServerStore()
  const { currentPage, sidebarCollapsed } = useUIStore()

  useEffect(() => {
    fetchServers()
  }, [fetchServers])

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardPage />
      case 'server-overview':
        return <ServerOverviewPage />
      case 'console':
        return <ConsolePage />
      case 'files':
        return <FileManagerPage />
      case 'players':
        return <PlayersPage />
      case 'backups':
        return <BackupsPage />
      case 'admin':
      case 'admin-users':
      case 'admin-servers':
      case 'admin-settings':
        return <AdminPage />
      case 'profile':
        return <ProfilePage />
      default:
        return <DashboardPage />
    }
  }

  return (
    <div className="min-h-screen flex bg-[#0a0c10]">
      {/* Sidebar */}
      <div className={`${sidebarCollapsed ? 'w-[68px]' : 'w-[260px]'} transition-all duration-300 flex-shrink-0`}>
        <Sidebar />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        <Header />
        <main className="flex-1 overflow-auto p-4 lg:p-6">
          {renderPage()}
        </main>
      </div>
    </div>
  )
}
