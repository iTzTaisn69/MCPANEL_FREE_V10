'use client'

import { useAuthStore } from '@/stores/authStore'
import { useServerStore } from '@/stores/serverStore'
import { useUIStore, type PageId } from '@/stores/uiStore'
import { cn } from '@/lib/utils'
import {
  LayoutDashboard,
  Server,
  Terminal,
  FolderOpen,
  Users,
  HardDrive,
  Shield,
  UserCircle,
  ChevronLeft,
  ChevronRight,
  Pickaxe,
  Settings,
} from 'lucide-react'

const mainNavItems = [
  { id: 'dashboard' as PageId, label: 'Dashboard', icon: LayoutDashboard },
]

const serverNavItems = [
  { id: 'server-overview' as PageId, label: 'Overview', icon: Server },
  { id: 'console' as PageId, label: 'Console', icon: Terminal },
  { id: 'files' as PageId, label: 'Files', icon: FolderOpen },
  { id: 'players' as PageId, label: 'Players', icon: Users },
  { id: 'backups' as PageId, label: 'Backups', icon: HardDrive },
]

const adminNavItems = [
  { id: 'admin' as PageId, label: 'Admin Panel', icon: Shield },
  { id: 'admin-settings' as PageId, label: 'Settings', icon: Settings },
]

export function Sidebar() {
  const { user } = useAuthStore()
  const { selectedServerId } = useServerStore()
  const { currentPage, sidebarCollapsed, setPage, toggleSidebar, navigateToServer } = useUIStore()
  const { servers } = useServerStore()

  const handleServerNav = (page: PageId) => {
    if (selectedServerId) {
      navigateToServer(selectedServerId, page)
    }
  }

  return (
    <aside className="h-screen sticky top-0 flex flex-col bg-[#0d0f14] border-r border-white/[0.06]">
      {/* Logo */}
      <div className={cn(
        "h-16 flex items-center gap-3 px-4 border-b border-white/[0.06] flex-shrink-0",
        sidebarCollapsed && "justify-center px-2"
      )}>
        <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center flex-shrink-0 shadow-lg shadow-emerald-500/20">
          <Pickaxe className="w-5 h-5 text-black" />
        </div>
        {!sidebarCollapsed && (
          <div className="min-w-0">
            <h1 className="text-sm font-bold text-white truncate">MCPanel</h1>
            <p className="text-[10px] text-muted-foreground">v2.0</p>
          </div>
        )}
      </div>

      {/* Navigation */}
      <div className="flex-1 overflow-y-auto py-3 px-2 space-y-1">
        {/* Main nav */}
        {mainNavItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setPage(item.id)}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-200",
              currentPage === item.id
                ? "bg-emerald-500/10 text-emerald-400"
                : "text-muted-foreground hover:bg-white/[0.04] hover:text-white"
            )}
          >
            <item.icon className={cn("w-4 h-4 flex-shrink-0", currentPage === item.id && "text-emerald-400")} />
            {!sidebarCollapsed && <span className="truncate">{item.label}</span>}
            {currentPage === item.id && !sidebarCollapsed && (
              <div className="ml-auto w-1.5 h-1.5 rounded-full bg-emerald-400" />
            )}
          </button>
        ))}

        {/* Server section */}
        {selectedServerId && !sidebarCollapsed && (
          <div className="mt-4 mb-2 px-3">
            <div className="flex items-center gap-2 mb-1">
              <div className="h-px flex-1 bg-white/[0.06]" />
              <span className="text-[10px] text-muted-foreground/60 uppercase tracking-wider">Server</span>
              <div className="h-px flex-1 bg-white/[0.06]" />
            </div>
            {servers.find(s => s.id === selectedServerId) && (
              <p className="text-xs text-emerald-400/80 truncate mt-1">
                {servers.find(s => s.id === selectedServerId)?.name}
              </p>
            )}
          </div>
        )}

        {selectedServerId && serverNavItems.map((item) => (
          <button
            key={item.id}
            onClick={() => handleServerNav(item.id)}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-200",
              currentPage === item.id
                ? "bg-emerald-500/10 text-emerald-400"
                : "text-muted-foreground hover:bg-white/[0.04] hover:text-white"
            )}
          >
            <item.icon className={cn("w-4 h-4 flex-shrink-0", currentPage === item.id && "text-emerald-400")} />
            {(!sidebarCollapsed || !selectedServerId) && <span className="truncate">{item.label}</span>}
            {currentPage === item.id && !sidebarCollapsed && (
              <div className="ml-auto w-1.5 h-1.5 rounded-full bg-emerald-400" />
            )}
          </button>
        ))}

        {/* Admin section */}
        {user?.role === 'admin' && (
          <>
            <div className="mt-4 mb-2 px-3">
              <div className="flex items-center gap-2">
                <div className="h-px flex-1 bg-white/[0.06]" />
                {!sidebarCollapsed && <span className="text-[10px] text-muted-foreground/60 uppercase tracking-wider">Admin</span>}
                <div className="h-px flex-1 bg-white/[0.06]" />
              </div>
            </div>
            {adminNavItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setPage(item.id)}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-200",
                  (currentPage === item.id || (currentPage.startsWith('admin') && item.id === 'admin'))
                    ? "bg-emerald-500/10 text-emerald-400"
                    : "text-muted-foreground hover:bg-white/[0.04] hover:text-white"
                )}
              >
                <item.icon className={cn("w-4 h-4 flex-shrink-0", 
                  (currentPage === item.id || (currentPage.startsWith('admin') && item.id === 'admin')) && "text-emerald-400"
                )} />
                {!sidebarCollapsed && <span className="truncate">{item.label}</span>}
              </button>
            ))}
          </>
        )}
      </div>

      {/* User section */}
      <div className="border-t border-white/[0.06] p-2 flex-shrink-0">
        <button
          onClick={() => setPage('profile')}
          className={cn(
            "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-200",
            currentPage === 'profile'
              ? "bg-emerald-500/10 text-emerald-400"
              : "text-muted-foreground hover:bg-white/[0.04] hover:text-white"
          )}
        >
          <div className="w-7 h-7 rounded-full bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 border border-white/10 flex items-center justify-center flex-shrink-0">
            <UserCircle className="w-4 h-4" />
          </div>
          {!sidebarCollapsed && (
            <div className="min-w-0 text-left">
              <p className="text-xs font-medium text-white truncate">{user?.displayName || user?.username}</p>
              <p className="text-[10px] text-muted-foreground capitalize">{user?.role}</p>
            </div>
          )}
        </button>
      </div>

      {/* Collapse toggle */}
      <button
        onClick={toggleSidebar}
        className="h-10 flex items-center justify-center border-t border-white/[0.06] text-muted-foreground hover:text-white hover:bg-white/[0.04] transition-all duration-200 flex-shrink-0"
      >
        {sidebarCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
      </button>
    </aside>
  )
}
