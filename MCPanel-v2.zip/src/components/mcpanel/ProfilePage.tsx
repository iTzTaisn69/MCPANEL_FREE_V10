'use client'

import { useState } from 'react'
import { useAuthStore } from '@/stores/authStore'
import { useUIStore } from '@/stores/uiStore'
import { cn } from '@/lib/utils'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
  User,
  Mail,
  Lock,
  Key,
  Shield,
  Save,
  Check,
} from 'lucide-react'

export function ProfilePage() {
  const { user } = useAuthStore()
  const [displayName, setDisplayName] = useState(user?.displayName || '')
  const [email, setEmail] = useState(user?.email || '')
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [saved, setSaved] = useState(false)

  const handleSave = () => {
    // In a real app, this would call the API
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <div className="max-w-2xl space-y-6 fade-in">
      {/* Profile header */}
      <div className="glass rounded-xl p-6">
        <div className="flex items-center gap-5">
          <Avatar className="w-20 h-20">
            <AvatarFallback className="bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 border-2 border-white/10 text-2xl font-bold text-emerald-400">
              {user?.username?.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div>
            <h2 className="text-xl font-bold text-white">{user?.displayName || user?.username}</h2>
            <div className="flex items-center gap-2 mt-1">
              <Badge className={cn(
                "text-[10px] border-0",
                user?.role === 'admin' ? 'bg-amber-500/10 text-amber-400' : 'bg-white/5 text-muted-foreground'
              )}>
                <Shield className="w-3 h-3 mr-1" />
                {user?.role}
              </Badge>
              <Badge className="text-[10px] border-0 bg-emerald-500/10 text-emerald-400">
                Active
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Member since {user ? new Date().toLocaleDateString() : 'N/A'}
            </p>
          </div>
        </div>
      </div>

      {/* Profile info */}
      <Card className="bg-[#111318] border-white/[0.06]">
        <CardHeader>
          <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <User className="w-4 h-4" /> Profile Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs text-muted-foreground font-medium">Username</label>
              <Input
                value={user?.username || ''}
                disabled
                className="bg-[#0a0c10] border-white/10 text-muted-foreground"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs text-muted-foreground font-medium">Display Name</label>
              <Input
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="bg-[#0a0c10] border-white/10 text-white"
              />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs text-muted-foreground font-medium flex items-center gap-1.5">
              <Mail className="w-3 h-3" /> Email Address
            </label>
            <Input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-[#0a0c10] border-white/10 text-white"
            />
          </div>
          <Button onClick={handleSave} className="bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border-0">
            {saved ? <Check className="w-4 h-4 mr-1.5" /> : <Save className="w-4 h-4 mr-1.5" />}
            {saved ? 'Saved!' : 'Save Changes'}
          </Button>
        </CardContent>
      </Card>

      {/* Change password */}
      <Card className="bg-[#111318] border-white/[0.06]">
        <CardHeader>
          <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <Key className="w-4 h-4" /> Change Password
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-xs text-muted-foreground font-medium">Current Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="pl-10 bg-[#0a0c10] border-white/10 text-white"
                placeholder="Enter current password"
              />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs text-muted-foreground font-medium">New Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="pl-10 bg-[#0a0c10] border-white/10 text-white"
                placeholder="Enter new password"
              />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs text-muted-foreground font-medium">Confirm New Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="pl-10 bg-[#0a0c10] border-white/10 text-white"
                placeholder="Confirm new password"
              />
            </div>
          </div>
          <Button onClick={handleSave} className="bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border-0">
            Update Password
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
