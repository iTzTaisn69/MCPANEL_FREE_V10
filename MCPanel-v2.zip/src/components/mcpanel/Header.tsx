'use client'

import { useAuthStore } from '@/stores/authStore'
import { useServerStore } from '@/stores/serverStore'
import { useUIStore } from '@/stores/uiStore'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Bell,
  LogOut,
  Search,
  Menu,
} from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

export function Header() {
  const { user, logout } = useAuthStore()
  const { servers } = useServerStore()
  const { currentPage, setPage, selectedServerId } = useUIStore()

  const onlineCount = servers.filter(s => s.status === 'online').length
  const selectedServer = servers.find(s => s.id === selectedServerId)

  const getPageTitle = () => {
    switch (currentPage) {
      case 'dashboard': return 'Dashboard'
      case 'server-overview': return selectedServer?.name || 'Server Overview'
      case 'console': return selectedServer?.name ? `${selectedServer.name} — Console` : 'Console'
      case 'files': return selectedServer?.name ? `${selectedServer.name} — Files` : 'File Manager'
      case 'players': return selectedServer?.name ? `${selectedServer.name} — Players` : 'Players'
      case 'backups': return selectedServer?.name ? `${selectedServer.name} — Backups` : 'Backups'
      case 'admin': return 'Admin Panel'
      case 'admin-users': return 'Admin — Users'
      case 'admin-servers': return 'Admin — Servers'
      case 'admin-settings': return 'Admin — Settings'
      case 'profile': return 'Profile'
      default: return 'Dashboard'
    }
  }

  return (
    <header className="h-16 flex items-center justify-between px-4 lg:px-6 border-b border-white/[0.06] bg-[#0d0f14]/50 backdrop-blur-md flex-shrink-0 sticky top-0 z-30">
      {/* Left side */}
      <div className="flex items-center gap-4">
        <h2 className="text-lg font-semibold text-white">{getPageTitle()}</h2>
        {selectedServer && (
          <Badge 
            variant="outline" 
            className={`text-[10px] px-2 py-0 h-5 border-0 ${
              selectedServer.status === 'online' 
                ? 'bg-emerald-500/10 text-emerald-400' 
                : selectedServer.status === 'starting' || selectedServer.status === 'stopping' || selectedServer.status === 'restarting'
                ? 'bg-amber-500/10 text-amber-400'
                : 'bg-white/5 text-muted-foreground'
            }`}
          >
            <span className={`w-1.5 h-1.5 rounded-full mr-1.5 inline-block ${
              selectedServer.status === 'online' ? 'bg-emerald-400 pulse-dot' : 
              selectedServer.status === 'starting' || selectedServer.status === 'stopping' || selectedServer.status === 'restarting'
              ? 'bg-amber-400 pulse-dot' : 'bg-muted-foreground/50'
            }`} />
            {selectedServer.status}
          </Badge>
        )}
      </div>

      {/* Right side */}
      <div className="flex items-center gap-2">
        {/* Server status summary */}
        <div className="hidden sm:flex items-center gap-2 mr-2 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 pulse-dot" />
            {onlineCount} online
          </span>
          <span className="text-white/10">|</span>
          <span>{servers.length} total</span>
        </div>

        {/* Notifications */}
        <Button variant="ghost" size="icon" className="relative text-muted-foreground hover:text-white hover:bg-white/[0.04] h-9 w-9">
          <Bell className="w-4 h-4" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-emerald-500 rounded-full" />
        </Button>

        {/* User menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="flex items-center gap-2 hover:bg-white/[0.04] h-9 px-2">
              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 border border-white/10 flex items-center justify-center">
                <span className="text-xs font-medium text-emerald-400">
                  {user?.username?.charAt(0).toUpperCase()}
                </span>
              </div>
              <span className="hidden md:inline text-sm text-muted-foreground">{user?.displayName || user?.username}</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48 bg-[#111318] border-white/10">
            <DropdownMenuItem onClick={() => setPage('profile')} className="text-muted-foreground focus:text-white focus:bg-white/[0.04]">
              Profile Settings
            </DropdownMenuItem>
            <DropdownMenuSeparator className="bg-white/[0.06]" />
            <DropdownMenuItem onClick={logout} className="text-destructive focus:text-destructive focus:bg-white/[0.04]">
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}
