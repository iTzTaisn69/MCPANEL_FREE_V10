import { create } from 'zustand'

interface ServerStats {
  cpu: number
  ram: number
  disk: number
  playerCount: number
  players: string[]
}

interface Server {
  id: number
  name: string
  ownerId: number
  ram: number
  cpu: number
  disk: number
  port: number
  serverIp: string
  status: string
  version: string
  serverType: string
  owner?: { username: string; displayName: string | null }
  members?: { id: number; role: string; user: { username: string; displayName: string | null } }[]
  backups?: { id: number; name: string; size: string | null; createdAt: string }[]
  createdAt: string
  updatedAt: string
}

interface ServerState {
  servers: Server[]
  selectedServer: Server | null
  serverStats: Map<number, ServerStats>
  isLoading: boolean
  fetchServers: () => Promise<void>
  selectServer: (serverId: number) => Promise<void>
  updateServerStatus: (serverId: number, status: string) => void
  updateServerStats: (serverId: number, stats: ServerStats) => void
  startServer: (serverId: number) => Promise<boolean>
  stopServer: (serverId: number) => Promise<boolean>
  restartServer: (serverId: number) => Promise<boolean>
  sendCommand: (serverId: number, command: string) => Promise<boolean>
}

export const useServerStore = create<ServerState>((set, get) => ({
  servers: [],
  selectedServer: null,
  serverStats: new Map(),
  isLoading: false,

  fetchServers: async () => {
    set({ isLoading: true })
    try {
      const token = localStorage.getItem('mcpanel_token')
      const res = await fetch('/api/servers', {
        headers: { Authorization: `Bearer ${token}` },
      })
      const data = await res.json()
      if (data.success) {
        set({ servers: data.servers, isLoading: false })
      } else {
        set({ isLoading: false })
      }
    } catch {
      set({ isLoading: false })
    }
  },

  selectServer: async (serverId: number) => {
    try {
      const token = localStorage.getItem('mcpanel_token')
      const res = await fetch(`/api/servers/${serverId}`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      const data = await res.json()
      if (data.success) {
        set({ selectedServer: data.server })
      }
    } catch {
      // ignore
    }
  },

  updateServerStatus: (serverId: number, status: string) => {
    set((state) => ({
      servers: state.servers.map(s => s.id === serverId ? { ...s, status } : s),
      selectedServer: state.selectedServer?.id === serverId
        ? { ...state.selectedServer, status }
        : state.selectedServer,
    }))
  },

  updateServerStats: (serverId: number, stats: ServerStats) => {
    set((state) => {
      const newStats = new Map(state.serverStats)
      newStats.set(serverId, stats)
      return { serverStats: newStats }
    })
  },

  startServer: async (serverId: number) => {
    try {
      const token = localStorage.getItem('mcpanel_token')
      const res = await fetch(`/api/servers/${serverId}/start`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      })
      const data = await res.json()
      return data.success
    } catch {
      return false
    }
  },

  stopServer: async (serverId: number) => {
    try {
      const token = localStorage.getItem('mcpanel_token')
      const res = await fetch(`/api/servers/${serverId}/stop`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      })
      const data = await res.json()
      return data.success
    } catch {
      return false
    }
  },

  restartServer: async (serverId: number) => {
    try {
      const token = localStorage.getItem('mcpanel_token')
      const res = await fetch(`/api/servers/${serverId}/restart`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      })
      const data = await res.json()
      return data.success
    } catch {
      return false
    }
  },

  sendCommand: async (serverId: number, command: string) => {
    try {
      const token = localStorage.getItem('mcpanel_token')
      const res = await fetch(`/api/servers/${serverId}/command`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ command }),
      })
      const data = await res.json()
      return data.success
    } catch {
      return false
    }
  },
}))
