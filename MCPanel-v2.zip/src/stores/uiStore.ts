import { create } from 'zustand'

export type PageId = 
  | 'dashboard' 
  | 'server-overview' 
  | 'console' 
  | 'files' 
  | 'players' 
  | 'backups' 
  | 'admin' 
  | 'admin-users' 
  | 'admin-servers' 
  | 'admin-settings'
  | 'profile'

interface UIState {
  currentPage: PageId
  sidebarCollapsed: boolean
  selectedServerId: number | null
  setPage: (page: PageId) => void
  toggleSidebar: () => void
  setSelectedServerId: (id: number | null) => void
  navigateToServer: (serverId: number, page?: PageId) => void
}

export const useUIStore = create<UIState>((set) => ({
  currentPage: 'dashboard',
  sidebarCollapsed: false,
  selectedServerId: null,

  setPage: (page: PageId) => set({ currentPage: page }),

  toggleSidebar: () => set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),

  setSelectedServerId: (id: number | null) => set({ selectedServerId: id }),

  navigateToServer: (serverId: number, page: PageId = 'server-overview') => {
    set({ selectedServerId: serverId, currentPage: page })
  },
}))
