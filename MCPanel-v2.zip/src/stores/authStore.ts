import { create } from 'zustand'

interface User {
  id: number
  username: string
  email: string
  role: string
  status: string
  displayName: string | null
  avatar: string | null
}

interface AuthState {
  user: User | null
  token: string | null
  isAuthenticated: boolean
  isLoading: boolean
  login: (username: string, password: string) => Promise<boolean>
  register: (username: string, email: string, password: string) => Promise<boolean>
  logout: () => void
  checkAuth: () => Promise<void>
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  token: null,
  isAuthenticated: false,
  isLoading: true,

  login: async (username: string, password: string) => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      })
      const data = await res.json()
      if (data.success) {
        localStorage.setItem('mcpanel_token', data.token)
        set({ user: data.user, token: data.token, isAuthenticated: true })
        return true
      }
      return false
    } catch {
      return false
    }
  },

  register: async (username: string, email: string, password: string) => {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, email, password }),
      })
      const data = await res.json()
      if (data.success) {
        localStorage.setItem('mcpanel_token', data.token)
        set({ user: data.user, token: data.token, isAuthenticated: true })
        return true
      }
      return false
    } catch {
      return false
    }
  },

  logout: () => {
    localStorage.removeItem('mcpanel_token')
    set({ user: null, token: null, isAuthenticated: false })
  },

  checkAuth: async () => {
    const token = localStorage.getItem('mcpanel_token')
    if (!token) {
      set({ isLoading: false, isAuthenticated: false, user: null, token: null })
      return
    }
    try {
      const res = await fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${token}` },
      })
      const data = await res.json()
      if (data.success) {
        set({ user: data.user, token, isAuthenticated: true, isLoading: false })
      } else {
        localStorage.removeItem('mcpanel_token')
        set({ user: null, token: null, isAuthenticated: false, isLoading: false })
      }
    } catch {
      set({ isLoading: false, isAuthenticated: false, user: null, token: null })
    }
  },
}))
