import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'

const TOKEN_SECRET = 'mcpanel-secret-key-2024'

export interface AuthUser {
  id: number
  username: string
  email: string
  role: string
  status: string
  displayName: string | null
  avatar: string | null
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10)
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash)
}

export function generateToken(user: AuthUser): string {
  const payload = JSON.stringify({
    id: user.id,
    username: user.username,
    role: user.role,
    exp: Date.now() + 7 * 24 * 60 * 60 * 1000, // 7 days
  })
  return Buffer.from(`${TOKEN_SECRET}:${payload}`).toString('base64')
}

export function verifyToken(token: string): AuthUser | null {
  try {
    const decoded = Buffer.from(token, 'base64').toString()
    const secretEnd = decoded.indexOf(':')
    if (secretEnd === -1) return null
    const secret = decoded.substring(0, secretEnd)
    const payload = decoded.substring(secretEnd + 1)
    if (secret !== TOKEN_SECRET) return null
    
    const data = JSON.parse(payload)
    if (data.exp < Date.now()) return null
    
    return {
      id: data.id,
      username: data.username,
      email: data.email || '',
      role: data.role,
      status: data.status || 'active',
      displayName: data.displayName || null,
      avatar: data.avatar || null,
    }
  } catch {
    return null
  }
}

export async function getUserFromRequest(request: Request): Promise<AuthUser | null> {
  const authHeader = request.headers.get('Authorization')
  if (!authHeader?.startsWith('Bearer ')) return null
  
  const token = authHeader.slice(7)
  const user = verifyToken(token)
  if (!user) return null
  
  // Verify user still exists in database
  const dbUser = await db.user.findUnique({ where: { id: user.id } })
  if (!dbUser || dbUser.status === 'suspended') return null
  
  return {
    id: dbUser.id,
    username: dbUser.username,
    email: dbUser.email,
    role: dbUser.role,
    status: dbUser.status,
    displayName: dbUser.displayName,
    avatar: dbUser.avatar,
  }
}
