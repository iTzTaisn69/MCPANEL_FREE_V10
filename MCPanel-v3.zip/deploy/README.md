# MCPanel v2 - VPS Deployment Guide (NPM Edition)

## Quick Install (One-Command)

Upload the ZIP to your VPS, then:

```bash
unzip MCPanel-v2.zip -d mcpanel-v2
cd mcpanel-v2
chmod +x deploy/setup-vps.sh
sudo ./deploy/setup-vps.sh
```

This automatically installs everything and starts the panel.

---

## Manual Install (Step by Step)

### 1. Server Requirements

| Requirement | Minimum | Recommended |
|------------|---------|-------------|
| OS | Ubuntu 20.04 / Debian 11 | Ubuntu 22.04+ |
| RAM | 1 GB | 2 GB+ |
| Disk | 5 GB | 20 GB+ |
| CPU | 1 core | 2+ cores |

### 2. Install Dependencies

```bash
sudo apt update && sudo apt install -y curl git nginx

# Node.js 22
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo bash -
sudo apt install -y nodejs

# tsx (TypeScript runner for Node.js)
sudo npm install -g tsx
```

### 3. Upload & Extract

```bash
# Upload MCPanel-v2.zip to your VPS via SCP or SFTP
scp MCPanel-v2.zip root@YOUR_VPS_IP:/opt/

# Then on your VPS:
cd /opt
unzip MCPanel-v2.zip -d mcpanel-v2
cd mcpanel-v2
```

### 4. Configure Environment

```bash
cp deploy/.env.example .env
nano .env
```

**IMPORTANT: Change these values:**
```env
NEXTAUTH_SECRET="your-random-32-char-string-here"
NEXTAUTH_URL="https://panel.yourdomain.com"
```

Generate a secret: `openssl rand -base64 48`

### 5. Install & Build

```bash
npm install
npx prisma generate
npx prisma db push
npm run build
```

### 6. Set Up Systemd Services

```bash
sudo cp deploy/systemd/mcpanel-web.service /etc/systemd/system/
sudo cp deploy/systemd/mcpanel-socket.service /etc/systemd/system/

# Fix the Node path if needed:
which node
# Edit the ExecStart path in both service files if node is not at /usr/bin/node
# sudo nano /etc/systemd/system/mcpanel-web.service
# sudo nano /etc/systemd/system/mcpanel-socket.service

sudo systemctl daemon-reload
sudo systemctl enable mcpanel-web mcpanel-socket
sudo systemctl start mcpanel-web mcpanel-socket
```

Check status:
```bash
sudo systemctl status mcpanel-web
sudo systemctl status mcpanel-socket
```

View logs:
```bash
sudo journalctl -u mcpanel-web -f
sudo journalctl -u mcpanel-socket -f
```

### 7. Configure Nginx

```bash
sudo cp deploy/nginx/mcpanel.conf /etc/nginx/sites-available/
sudo ln -sf /etc/nginx/sites-available/mcpanel.conf /etc/nginx/sites-enabled/

# Edit the server_name:
sudo nano /etc/nginx/sites-available/mcpanel.conf
# Change: server_name panel.yourdomain.com;

sudo nginx -t
sudo systemctl reload nginx
```

### 8. Add SSL (HTTPS)

```bash
sudo certbot --nginx -d panel.yourdomain.com
```

### 9. Firewall

```bash
sudo ufw allow 22/tcp     # SSH
sudo ufw allow 80/tcp     # HTTP
sudo ufw allow 443/tcp    # HTTPS
sudo ufw allow 25565/tcp  # Minecraft
sudo ufw enable
```

### 10. Done!

Open `https://panel.yourdomain.com` in your browser.

**Default login:** `admin` / `admin123`

**⚠️ CHANGE THE PASSWORD IMMEDIATELY after first login!**

---

## Managing Your Panel

```bash
# Restart
sudo systemctl restart mcpanel-web mcpanel-socket

# Stop
sudo systemctl stop mcpanel-web mcpanel-socket

# Start
sudo systemctl start mcpanel-web mcpanel-socket

# View logs
sudo journalctl -u mcpanel-web -f --no-pager -n 50
sudo journalctl -u mcpanel-socket -f --no-pager -n 50

# Update (after uploading new code)
cd /opt/mcpanel-v2
npm install
npx prisma generate
npx prisma db push
npm run build
sudo systemctl restart mcpanel-web mcpanel-socket
```

---

## Architecture

```
Internet → Nginx (80/443) → Next.js App (3000) [Node.js]
                            → Socket.IO (3003) [Node.js + tsx]
                                ↓
                           SQLite DB
```

- **Next.js (port 3000)** - Main web interface & API (Node.js standalone server)
- **Socket.IO (port 3003)** - Real-time console & server stats (Node.js + tsx)
- **Nginx** - Reverse proxy, SSL termination, static caching
- **SQLite** - Lightweight database, no extra setup needed

---

## Troubleshooting

### Panel not loading?
```bash
# Check if services are running
sudo systemctl status mcpanel-web mcpanel-socket

# Check Nginx
sudo nginx -t
sudo systemctl status nginx

# Check ports
sudo ss -tlnp | grep -E '3000|3003|80|443'
```

### Socket.IO not connecting?
- Make sure `mcpanel-socket` service is running
- Check Nginx config has the `/socket.io/` location block
- Check your browser console for connection errors
- Verify tsx is installed: `which tsx`

### Build fails?
```bash
# Clear cache and rebuild
rm -rf .next node_modules
npm install
npx prisma generate
npm run build
```

### Database issues?
```bash
# Reset database (WARNING: deletes all data)
npx prisma migrate reset

# Or just re-push schema
npx prisma db push
```

### Node.js path issues?
```bash
# Find your node path
which node
# e.g. /usr/bin/node or /usr/local/bin/node

# Update service files
sudo nano /etc/systemd/system/mcpanel-web.service
sudo nano /etc/systemd/system/mcpanel-socket.service
# Change ExecStart to use your node path

sudo systemctl daemon-reload
sudo systemctl restart mcpanel-web mcpanel-socket
```
