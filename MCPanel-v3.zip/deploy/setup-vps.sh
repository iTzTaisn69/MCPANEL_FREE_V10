#!/bin/bash
# ============================================
# MCPanel v2 - VPS Setup Script (NPM Edition)
# ============================================
# Run this on a fresh Ubuntu/Debian VPS:
#   chmod +x setup-vps.sh
#   sudo ./setup-vps.sh
# ============================================

set -e

echo "============================================"
echo "  MCPanel v2 - VPS Installer (NPM)"
echo "============================================"
echo ""

# --- Check root ---
if [ "$EUID" -ne 0 ]; then
  echo "❌ Please run as root: sudo ./setup-vps.sh"
  exit 1
fi

# --- Config ---
PANEL_DIR="/opt/mcpanel-v2"
PANEL_USER="mcpanel"
NODE_VERSION="22"

echo "📦 Step 1/7: Installing system dependencies..."
apt-get update -y
apt-get install -y curl wget git unzip tar nginx certbot python3-certbot-nginx ufw

echo ""
echo "📦 Step 2/7: Installing Node.js ${NODE_VERSION}..."
if ! command -v node &> /dev/null; then
  curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | bash -
  apt-get install -y nodejs
fi
echo "  Node.js: $(node -v)"
echo "  npm: $(npm -v)"

echo ""
echo "📦 Step 3/7: Installing tsx (TypeScript runner for Node)..."
npm install -g tsx
echo "  tsx: $(tsx --version 2>/dev/null || echo 'installed')"

echo ""
echo "📦 Step 4/7: Creating panel user & directories..."
if ! id "$PANEL_USER" &>/dev/null; then
  useradd -m -s /bin/bash "$PANEL_USER"
  echo "  ✅ User '$PANEL_USER' created"
else
  echo "  ⏩ User '$PANEL_USER' already exists"
fi

mkdir -p "$PANEL_DIR"
mkdir -p "$PANEL_DIR/db"
mkdir -p "$PANEL_DIR/logs"
mkdir -p "$PANEL_DIR/uploads"

echo ""
echo "📦 Step 5/7: Copying panel files..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PARENT_DIR="$(dirname "$SCRIPT_DIR")"

if [ -f "$SCRIPT_DIR/package.json" ]; then
  SRC="$SCRIPT_DIR"
elif [ -f "$PARENT_DIR/package.json" ]; then
  SRC="$PARENT_DIR"
else
  echo "❌ Cannot find panel source files. Make sure this script is in the MCPanel-v2 directory."
  exit 1
fi

echo "  Copying from: $SRC"
cp -r "$SRC/src" "$PANEL_DIR/"
cp -r "$SRC/prisma" "$PANEL_DIR/"
cp -r "$SRC/public" "$PANEL_DIR/"
cp -r "$SRC/mini-services" "$PANEL_DIR/"
cp "$SRC/package.json" "$PANEL_DIR/"
cp "$SRC/tsconfig.json" "$PANEL_DIR/"
cp "$SRC/tailwind.config.ts" "$PANEL_DIR/"
cp "$SRC/postcss.config.mjs" "$PANEL_DIR/"
cp "$SRC/next.config.ts" "$PANEL_DIR/"
cp "$SRC/eslint.config.mjs" "$PANEL_DIR/" 2>/dev/null || true
cp "$SRC/components.json" "$PANEL_DIR/" 2>/dev/null || true
cp -r "$SRC/deploy" "$PANEL_DIR/" 2>/dev/null || true

echo ""
echo "📦 Step 6/7: Installing dependencies & building..."
cd "$PANEL_DIR"

npm install
npx prisma generate

if [ ! -f .env ]; then
  cat > .env << 'ENVEOF'
# MCPanel v2 Environment Configuration
DATABASE_URL="file:./db/custom.db"
NEXTAUTH_SECRET="CHANGE_ME_TO_A_RANDOM_STRING_AT_LEAST_32_CHARS"
NEXTAUTH_URL="http://localhost:3000"
SOCKET_PORT=3003
NODE_ENV=production
ENVEOF
  echo "  ⚠️  Created default .env - EDIT IT before going live!"
fi

npx prisma db push
npm run build

echo ""
echo "📦 Step 7/7: Installing systemd services..."
cp "$PANEL_DIR/deploy/systemd/"* /etc/systemd/system/ 2>/dev/null || true

# Fix paths in service files
sed -i "s|/opt/mcpanel-v2|$PANEL_DIR|g" /etc/systemd/system/mcpanel*.service 2>/dev/null || true
sed -i "s|User=mcpanel|User=$PANEL_USER|g" /etc/systemd/system/mcpanel*.service 2>/dev/null || true

# Fix the node path in service files
NODE_PATH=$(which node)
NPX_PATH=$(which npx)
TSX_PATH=$(which tsx)
sed -i "s|/usr/bin/node|$NODE_PATH|g" /etc/systemd/system/mcpanel*.service 2>/dev/null || true
sed -i "s|/usr/bin/npx|$NPX_PATH|g" /etc/systemd/system/mcpanel*.service 2>/dev/null || true
sed -i "s|/usr/bin/tsx|$TSX_PATH|g" /etc/systemd/system/mcpanel*.service 2>/dev/null || true

systemctl daemon-reload
systemctl enable mcpanel-web mcpanel-socket 2>/dev/null || true
systemctl start mcpanel-web mcpanel-socket 2>/dev/null || true

chown -R "$PANEL_USER:$PANEL_USER" "$PANEL_DIR"

echo ""
echo "============================================"
echo "  ✅ MCPanel v2 Installation Complete!"
echo "============================================"
echo ""
echo "📋 Next Steps:"
echo ""
echo "  1. Edit your environment config:"
echo "     nano $PANEL_DIR/.env"
echo "     → Set NEXTAUTH_SECRET to a random 32+ char string"
echo "     → Set NEXTAUTH_URL to your domain (e.g. https://panel.yourdomain.com)"
echo ""
echo "  2. Restart services after editing .env:"
echo "     systemctl restart mcpanel-web mcpanel-socket"
echo ""
echo "  3. Set up Nginx reverse proxy:"
echo "     cp $PANEL_DIR/deploy/nginx/mcpanel.conf /etc/nginx/sites-available/"
echo "     ln -sf /etc/nginx/sites-available/mcpanel.conf /etc/nginx/sites-enabled/"
echo "     nginx -t && systemctl reload nginx"
echo ""
echo "  4. Add SSL (optional but recommended):"
echo "     certbot --nginx -d panel.yourdomain.com"
echo ""
echo "  5. Open firewall:"
echo "     ufw allow 80/tcp"
echo "     ufw allow 443/tcp"
echo "     ufw allow 25565/tcp  # Minecraft server port"
echo "     ufw enable"
echo ""
echo "  6. Access your panel:"
echo "     http://YOUR_VPS_IP  (or https://panel.yourdomain.com)"
echo ""
echo "  Default Login: admin / admin123"
echo "  ⚠️  CHANGE THE PASSWORD after first login!"
echo ""
