import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { hashPassword } from '@/lib/auth'

export async function POST() {
  try {
    // Check if admin user exists
    const existingAdmin = await db.user.findUnique({ where: { username: 'admin' } })
    
    if (existingAdmin) {
      return NextResponse.json({ success: true, message: 'Database already seeded' })
    }

    // Create admin user
    const hashedPassword = await hashPassword('admin123')
    const admin = await db.user.create({
      data: {
        username: 'admin',
        email: 'admin@mcpanel.local',
        password: hashedPassword,
        role: 'admin',
        displayName: 'Admin',
      },
    })

    // Create sample servers
    const servers = [
      { name: 'Survival World', serverType: 'vanilla', version: '1.21.4', port: 25565, ram: 2048, cpu: 2, disk: 20480, status: 'online' },
      { name: 'Creative Hub', serverType: 'spigot', version: '1.21.4', port: 25566, ram: 1024, cpu: 1, disk: 10240, status: 'online' },
      { name: 'Skyblock', serverType: 'paper', version: '1.20.4', port: 25567, ram: 4096, cpu: 4, disk: 40960, status: 'stopped' },
      { name: 'Factions', serverType: 'purpur', version: '1.21.4', port: 25568, ram: 2048, cpu: 2, disk: 20480, status: 'stopped' },
      { name: 'Bed Wars', serverType: 'paper', version: '1.21.4', port: 25569, ram: 3072, cpu: 3, disk: 30720, status: 'online' },
    ]

    for (const serverData of servers) {
      const server = await db.server.create({
        data: {
          ...serverData,
          ownerId: admin.id,
          serverIp: 'localhost',
        },
      })

      // Add admin as server member
      await db.serverMember.create({
        data: {
          serverId: server.id,
          userId: admin.id,
          role: 'admin',
          permissions: JSON.stringify(['*']),
        },
      })

      // Create some backups for each server
      const backupNames = ['Daily Backup', 'Pre-update Backup', 'World Save']
      for (const backupName of backupNames) {
        await db.backup.create({
          data: {
            serverId: server.id,
            name: backupName,
            size: `${(Math.random() * 500 + 50).toFixed(1)} MB`,
          },
        })
      }
    }

    // Create a regular user
    const regularUser = await db.user.create({
      data: {
        username: 'player1',
        email: 'player1@mcpanel.local',
        password: await hashPassword('player123'),
        role: 'user',
        displayName: 'Player One',
      },
    })

    // Add regular user to first two servers
    const firstTwoServers = await db.server.findMany({ take: 2 })
    for (const server of firstTwoServers) {
      await db.serverMember.create({
        data: {
          serverId: server.id,
          userId: regularUser.id,
          role: 'member',
          permissions: JSON.stringify(['console', 'files.read']),
        },
      })
    }

    // Create panel settings
    const settings = [
      { key: 'panelName', value: 'MCPanel v2' },
      { key: 'panelDescription', value: 'Modern Minecraft Server Control Panel' },
      { key: 'registrationEnabled', value: 'true' },
      { key: 'defaultServerType', value: 'vanilla' },
      { key: 'defaultVersion', value: '1.21.4' },
    ]

    for (const setting of settings) {
      await db.panelSettings.create({ data: setting })
    }

    // Create notifications for admin
    const notifications = [
      { userId: admin.id, title: 'Welcome to MCPanel', message: 'Your Minecraft server control panel is ready!', type: 'info' },
      { userId: admin.id, title: 'Server Online', message: 'Survival World server is now online.', type: 'success' },
      { userId: admin.id, title: 'Backup Complete', message: 'Daily backup completed for all servers.', type: 'success' },
      { userId: admin.id, title: 'High CPU Usage', message: 'Skyblock server is experiencing high CPU usage.', type: 'warning' },
    ]

    for (const notif of notifications) {
      await db.notification.create({ data: notif })
    }

    return NextResponse.json({ success: true, message: 'Database seeded successfully' })
  } catch (error) {
    console.error('Seed error:', error)
    return NextResponse.json({ success: false, error: 'Internal server error' }, { status: 500 })
  }
}
